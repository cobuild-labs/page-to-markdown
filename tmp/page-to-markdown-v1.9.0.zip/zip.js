/**
 * zip.js - a tiny .zip writer used by the AI chat export to bundle the chat's
 * Markdown with the files the chat made.
 *
 * Injected into the page next to aiexport.js. No libraries: compression uses
 * the browser's own CompressionStream('deflate-raw'); if that is missing or
 * does not shrink a file (images, pdf, xlsx are already compressed), the file
 * is stored as is. Nothing is sent anywhere.
 *
 * window.__ptmZip(entries) -> Promise<Blob>
 *   entries: [{ name: 'folder/file.ext', data: Uint8Array | ArrayBuffer | string, date?: Date }]
 */
(function () {
  'use strict';
  if (window.__ptmZip) return;

  var CRC_TABLE = (function () {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(bytes) {
    var c = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function toBytes(data) {
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    return new TextEncoder().encode(String(data == null ? '' : data));
  }

  async function deflate(bytes) {
    if (typeof CompressionStream === 'undefined' || bytes.length < 64) return null;
    try {
      var stream = new Blob([bytes]).stream().pipeThrough(new CompressionStream('deflate-raw'));
      var out = new Uint8Array(await new Response(stream).arrayBuffer());
      return out.length < bytes.length ? out : null;
    } catch (e) { return null; }
  }

  function dosTime(d) {
    return ((d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2)) & 0xFFFF;
  }
  function dosDate(d) {
    var y = Math.max(1980, d.getFullYear());
    return (((y - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF;
  }

  window.__ptmZip = async function (entries) {
    var parts = [];       // local headers + data
    var central = [];     // central directory records
    var offset = 0;

    for (var i = 0; i < entries.length; i++) {
      var e = entries[i];
      var raw = toBytes(e.data);
      var name = new TextEncoder().encode(e.name);
      var crc = crc32(raw);
      var packed = await deflate(raw);
      var method = packed ? 8 : 0;
      var body = packed || raw;
      var d = e.date instanceof Date && !isNaN(e.date) ? e.date : new Date();

      var lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true);
      lh.setUint16(4, 20, true);
      lh.setUint16(6, 0x0800, true);          // names are UTF-8
      lh.setUint16(8, method, true);
      lh.setUint16(10, dosTime(d), true);
      lh.setUint16(12, dosDate(d), true);
      lh.setUint32(14, crc, true);
      lh.setUint32(18, body.length, true);
      lh.setUint32(22, raw.length, true);
      lh.setUint16(26, name.length, true);
      lh.setUint16(28, 0, true);
      parts.push(new Uint8Array(lh.buffer), name, body);

      var ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true);
      ch.setUint16(4, 20, true);
      ch.setUint16(6, 20, true);
      ch.setUint16(8, 0x0800, true);
      ch.setUint16(10, method, true);
      ch.setUint16(12, dosTime(d), true);
      ch.setUint16(14, dosDate(d), true);
      ch.setUint32(16, crc, true);
      ch.setUint32(20, body.length, true);
      ch.setUint32(24, raw.length, true);
      ch.setUint16(28, name.length, true);
      ch.setUint32(42, offset, true);
      central.push(new Uint8Array(ch.buffer), name);

      offset += 30 + name.length + body.length;
    }

    var cdSize = central.reduce(function (s, p) { return s + p.length; }, 0);
    var end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true);
    end.setUint16(8, entries.length, true);
    end.setUint16(10, entries.length, true);
    end.setUint32(12, cdSize, true);
    end.setUint32(16, offset, true);

    return new Blob(parts.concat(central, [new Uint8Array(end.buffer)]), { type: 'application/zip' });
  };
})();
