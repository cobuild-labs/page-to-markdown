/**
 * aiexport.js - "AI chat export" for Claude, ChatGPT, Gemini, Grok and, through
 * a general reader, most other AI chat apps (Copilot, Le Chat, Poe...).
 *
 * Injected into the chat tab with chrome.scripting.executeScript({files}),
 * then started with window.__ptmAiExport(options). Runs entirely inside the
 * user's own browser tab; nothing is sent anywhere. The Markdown file is
 * downloaded straight from the page, so the export finishes even if the
 * extension popup closes.
 *
 * options:
 *   mode            'chat'  - only your messages and the AI's replies
 *                   'full'  - plus thinking, every tool call (inputs such as
 *                             scripts/commands/queries) and every tool result
 *   includeSources  true/false - list links/citations the AI used
 *   maxToolChars    0 = keep tool inputs/results in full, else trim to N chars
 *   download        true = save the .md from the page (default true)
 *   withFiles       Claude: also save the files the chat made; the .md and the
 *                   files then come as one .zip (needs zip.js injected first)
 *   withUploads     with withFiles: also include the files you uploaded
 *   withCode        with withFiles: also include code/config files (.js, .py,
 *                   .css, .json...); off = they are listed by name only
 *   fast            tests only: skip waits
 */
(function () {
  'use strict';

  /* ------------------------------------------------------------------ *
   * Small helpers
   * ------------------------------------------------------------------ */
  function sleep(ms, opts) { return new Promise(function (r) { setTimeout(r, opts && opts.fast ? 0 : ms); }); }

  function absUrl(u) { try { return new URL(u, document.baseURI).href; } catch (e) { return u; } }

  function textOf(el) { return (el && el.textContent ? el.textContent : '').replace(/\s+/g, ' ').trim(); }

  // A code fence longer than any run of backticks inside the text, so tool
  // outputs that themselves contain ``` can't break the export.
  function fence(text, lang) {
    text = String(text == null ? '' : text);
    var longest = 2;
    var m = text.match(/`+/g);
    if (m) m.forEach(function (s) { if (s.length > longest) longest = s.length; });
    var f = new Array(longest + 2).join('`');
    return f + (lang || '') + '\n' + text.replace(/\n+$/, '') + '\n' + f;
  }

  function trim(text, max) {
    text = String(text == null ? '' : text);
    if (!max || text.length <= max) return text;
    return text.slice(0, max) + '\n... [trimmed ' + (text.length - max).toLocaleString() + ' more characters]';
  }

  function quote(text) {
    return String(text).replace(/\n{3,}/g, '\n\n').split('\n').map(function (l) { return '> ' + l; }).join('\n');
  }

  function fmtDate(iso) {
    if (!iso) return '';
    var d = new Date(iso);
    if (isNaN(d)) return '';
    function p(n) { return (n < 10 ? '0' : '') + n; }
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }

  function SourceList() {
    var seen = {};
    var list = [];
    return {
      add: function (url, title) {
        if (!url || !/^https?:/i.test(url)) return;
        var key = url.replace(/#.*$/, '');
        if (seen[key]) { if (title && !seen[key].title) seen[key].title = title; return; }
        seen[key] = { url: url, title: (title || '').trim() };
        list.push(seen[key]);
      },
      items: function () { return list; },
      md: function () {
        return list.map(function (s) { return '- ' + (s.title ? '[' + s.title.replace(/[\[\]]/g, '') + '](' + s.url + ')' : s.url); }).join('\n');
      }
    };
  }

  /* ------------------------------------------------------------------ *
   * On-page progress toast
   * ------------------------------------------------------------------ */
  var toastEl = null;
  function toast(msg) {
    try {
      if (!toastEl) {
        toastEl = document.createElement('div');
        toastEl.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;max-width:340px;' +
          'background:#111827;color:#fff;font:13px/1.45 -apple-system,Segoe UI,Roboto,sans-serif;' +
          'padding:10px 14px;border-radius:10px;box-shadow:0 6px 24px rgba(0,0,0,.25);';
        document.documentElement.appendChild(toastEl);
      }
      toastEl.textContent = 'AI export: ' + msg;
    } catch (e) { /* ignore */ }
  }
  function toastDone(msg) {
    toast(msg);
    setTimeout(function () { if (toastEl) { toastEl.remove(); toastEl = null; } }, 4000);
  }

  /* ------------------------------------------------------------------ *
   * HTML -> Markdown (for the on-screen sites)
   * ------------------------------------------------------------------ */
  var SKIP = { SCRIPT: 1, STYLE: 1, NOSCRIPT: 1, TEMPLATE: 1, SVG: 1, BUTTON: 1, IFRAME: 1, TEXTAREA: 1, INPUT: 1 };

  function isVisuallyHidden(el) {
    var cls = (el.getAttribute && el.getAttribute('class')) || '';
    if (/\b(sr-only|cdk-visually-hidden|visually-hidden|screen-reader[\w-]*)\b/.test(cls) && !/not-sr-only\b/.test(cls.replace(/print:not-sr-only/g, ''))) return true;
    if (el.getAttribute && el.getAttribute('aria-hidden') === 'true') return true;
    if (el.hasAttribute && el.hasAttribute('hidden')) return true;
    try {
      var cs = window.getComputedStyle(el);
      if (cs && (cs.display === 'none' || cs.visibility === 'hidden')) return true;
    } catch (e) { /* ignore */ }
    return false;
  }

  function htmlToMd(root, exclude, keepStepLabels) {
    exclude = exclude || new Set();
    function kids(n) { var s = ''; n.childNodes.forEach(function (c) { s += node(c, n); }); return s; }
    function list(el, ordered) {
      var out = '\n', i = 1;
      Array.prototype.forEach.call(el.children, function (li) {
        if (li.tagName !== 'LI') return;
        var inner = kids(li).trim().split('\n').map(function (l, k) { return k === 0 ? l : (l.trim() ? '  ' + l : l); }).join('\n');
        out += (ordered ? (i++) + '. ' : '- ') + inner + '\n';
      });
      return out + '\n';
    }
    function table(el) {
      var rows = Array.prototype.slice.call(el.querySelectorAll('tr'));
      if (!rows.length) return '';
      var w = 0;
      var g = rows.map(function (r) {
        var c = Array.prototype.slice.call(r.querySelectorAll('th,td')).map(function (x) { return textOf(x).replace(/\|/g, '\\|') || ' '; });
        w = Math.max(w, c.length); return c;
      });
      g.forEach(function (r) { while (r.length < w) r.push(' '); });
      var out = '\n| ' + g[0].join(' | ') + ' |\n|' + new Array(w + 1).join(' --- |') + '\n';
      for (var k = 1; k < g.length; k++) out += '| ' + g[k].join(' | ') + ' |\n';
      return out + '\n';
    }
    function node(n) {
      if (n.nodeType === 3) return (n.nodeValue || '').replace(/[ \t\r\n]+/g, ' ');
      if (n.nodeType !== 1) return '';
      var el = n, tag = el.tagName.toUpperCase();
      if (exclude.has(el)) return '';
      // Inline source chips / citation badges: keep the label as a marker.
      var cls = el.getAttribute('class') || '';
      if (/source-inline-chip/.test(cls) || el.getAttribute('data-d-component') === 'badge') {
        var lbl = textOf(el);
        return lbl ? ' [source: ' + lbl + '] ' : '';
      }
      // Agent apps put each step's label ("Read Q3 model", "Ran calculation")
      // in a toggle button; keep those in the full export.
      if (keepStepLabels && (tag === 'BUTTON' || el.getAttribute('role') === 'button') && el.hasAttribute('aria-expanded')) {
        var stepLabel = textOf(el);
        if (stepLabel.length > 3 && stepLabel.length < 200) return '\n\n**[Step: ' + stepLabel.replace(/[\[\]]/g, '') + ']**\n\n';
      }
      if (SKIP[tag] || tag.indexOf('-') > 0 && /^(MESSAGE-ACTIONS|COPY-BUTTON|THUMB-UP-BUTTON|THUMB-DOWN-BUTTON|SOURCES-CAROUSEL-INLINE)$/.test(tag)) return '';
      if (isVisuallyHidden(el)) return '';
      switch (tag) {
        case 'BR': return '  \n';
        case 'HR': return '\n\n---\n\n';
        case 'H1': case 'H2': case 'H3': case 'H4': case 'H5': case 'H6':
          return '\n\n' + new Array(+tag[1] + 1).join('#') + ' ' + kids(el).trim() + '\n\n';
        case 'STRONG': case 'B': { var b = kids(el).trim(); return b ? '**' + b + '**' : ''; }
        case 'EM': case 'I': { var it = kids(el).trim(); return it ? '*' + it + '*' : ''; }
        case 'DEL': case 'S': { var d = kids(el).trim(); return d ? '~~' + d + '~~' : ''; }
        case 'CODE':
          if (el.parentElement && el.parentElement.tagName === 'PRE') return el.textContent;
          return el.textContent.trim() ? '`' + el.textContent.trim() + '`' : '';
        case 'PRE': {
          var codeEl = el.querySelector('code') || el;
          var lang = ((codeEl.getAttribute('class') || '').match(/language-([\w+-]+)/) || [])[1] || '';
          return '\n\n' + fence(codeEl.textContent, lang) + '\n\n';
        }
        case 'BLOCKQUOTE': { var q = kids(el).trim(); return q ? '\n\n' + quote(q) + '\n\n' : ''; }
        case 'A': {
          var href = el.getAttribute('href'), label = kids(el).trim() || textOf(el);
          if (!href || /^(javascript:|#)/i.test(href) || !label) return label;
          return '[' + label + '](' + absUrl(href) + ')';
        }
        case 'IMG': {
          var src = el.getAttribute('src');
          if (!src || /^data:/.test(src)) return el.getAttribute('alt') ? '[image: ' + el.getAttribute('alt') + ']' : '';
          return '![' + (el.getAttribute('alt') || '') + '](' + absUrl(src) + ')';
        }
        case 'UL': return list(el, false);
        case 'OL': return list(el, true);
        case 'TABLE': return table(el);
        case 'P': case 'DIV': case 'SECTION': case 'ARTICLE': case 'LI': case 'HEADER': case 'FOOTER': case 'FIGURE': {
          var inner = kids(el).trim();
          return inner ? '\n\n' + inner + '\n\n' : '';
        }
        default: return kids(el);
      }
    }
    return node(root).replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/[ \t]{2,}/g, ' ').trim();
  }

  /* ------------------------------------------------------------------ *
   * Interaction helpers for the on-screen sites
   * ------------------------------------------------------------------ */
  function allLinks(scope) {
    return Array.prototype.slice.call((scope || document).querySelectorAll('a[href^="http"]'));
  }

  function isChromeLink(a) {
    // Site navigation / sidebar / own-chat links, never sources.
    // Only real navigation areas; some apps (e.g. Grok) wrap the whole page in
    // a container whose class merely contains the word "sidebar".
    if (a.closest('nav, [data-testid="sidebar"], side-navigation-content, mat-sidenav, [class~="sidebar"], [role="navigation"]')) return true;
    var host = location.hostname.replace(/^www\./, '');
    var h = ''; try { h = new URL(a.href).hostname.replace(/^www\./, ''); } catch (e) { return true; }
    return h === host || /(^|\.)google\.com$/.test(h) && /accounts|support|policies|about/.test(a.href);
  }

  function pressEscape() {
    ['keydown', 'keyup'].forEach(function (t) {
      try { document.dispatchEvent(new KeyboardEvent(t, { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true })); } catch (e) { /* ignore */ }
    });
  }

  // Click a button that reveals more links (a "Sources" panel or a source
  // chip), collect any new external links that appeared, then close it.
  async function clickAndHarvest(btn, sources, opts) {
    var before = new Set(allLinks().map(function (a) { return a.href; }));
    try { btn.click(); } catch (e) { return; }
    await sleep(700, opts);
    allLinks().forEach(function (a) {
      if (before.has(a.href) || isChromeLink(a)) return;
      sources.add(a.href, textOf(a).slice(0, 140));
    });
    pressEscape();
    await sleep(150, opts);
    if (btn.getAttribute('aria-expanded') === 'true') { try { btn.click(); } catch (e) { /* ignore */ } }
    await sleep(150, opts);
  }

  // Expand collapsed sections whose button text/label matches a pattern.
  async function expandMatching(scope, pattern, opts) {
    var n = 0;
    Array.prototype.slice.call(scope.querySelectorAll('button, [role="button"]')).forEach(function (b) {
      var label = ((b.getAttribute('aria-label') || '') + ' ' + textOf(b)).trim();
      if (!pattern.test(label)) return;
      if (b.getAttribute('aria-expanded') === 'true') return;
      try { b.click(); n++; } catch (e) { /* ignore */ }
    });
    if (n) await sleep(600, opts);
    return n;
  }

  // Text inside a reply container that is NOT the main answer: this is where
  // expanded thinking / "worked for" panels end up on every site.
  function extraWorkText(container, mainEls, dropSelector) {
    var clone = container.cloneNode(true);
    // Map main elements in the original to the clone by index path.
    function pathOf(el) { var p = []; while (el && el !== container) { var i = Array.prototype.indexOf.call(el.parentNode.children, el); p.unshift(i); el = el.parentNode; } return p; }
    function byPath(root, p) { var el = root; for (var k = 0; k < p.length && el; k++) el = el.children[p[k]]; return el; }
    mainEls.forEach(function (m) { if (!m || !container.contains(m)) return; var c = byPath(clone, pathOf(m)); if (c) c.remove(); });
    if (dropSelector) { try { clone.querySelectorAll(dropSelector).forEach(function (e) { e.remove(); }); } catch (e) { /* ignore */ } }
    clone.querySelectorAll('button, [role="button"], svg, [class*="sr-only"], .cdk-visually-hidden').forEach(function (e) { e.remove(); });
    var t = (clone.innerText || clone.textContent || '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    return t.length > 15 ? t : '';
  }

  /* ------------------------------------------------------------------ *
   * Claude: full conversation data (everything behind the summaries)
   * ------------------------------------------------------------------ */
  function getCookie(name) {
    var m = document.cookie.match(new RegExp('(?:^|; )' + name.replace(/[-.]/g, '\\$&') + '=([^;]*)'));
    return m ? decodeURIComponent(m[1]) : '';
  }

  async function claudeFetchConversation(convId) {
    var orgIds = [];
    var cookieOrg = getCookie('lastActiveOrg');
    if (cookieOrg) orgIds.push(cookieOrg);
    try {
      var orgs = await fetch('/api/organizations', { credentials: 'include' }).then(function (r) { return r.ok ? r.json() : []; });
      (orgs || []).forEach(function (o) { if (o && o.uuid && orgIds.indexOf(o.uuid) < 0) orgIds.push(o.uuid); });
    } catch (e) { /* fall through */ }
    for (var i = 0; i < orgIds.length; i++) {
      var url = '/api/organizations/' + orgIds[i] + '/chat_conversations/' + convId +
        '?tree=True&rendering_mode=messages&render_all_tools=true';
      try {
        var r = await fetch(url, { credentials: 'include' });
        if (r.ok) { var conv = await r.json(); conv.__org = orgIds[i]; return conv; }
      } catch (e) { /* try next org */ }
    }
    throw new Error('Could not load this conversation\'s data (are you signed in?)');
  }

  // Follow the branch that is currently shown (edits/retries create branches).
  function claudeActiveBranch(conv) {
    var msgs = conv.chat_messages || [];
    var byId = {};
    msgs.forEach(function (m) { byId[m.uuid] = m; });
    var leaf = conv.current_leaf_message_uuid && byId[conv.current_leaf_message_uuid];
    if (!leaf) return msgs.slice().sort(function (a, b) { return (a.index || 0) - (b.index || 0); });
    var chain = [], cur = leaf, guard = 0;
    while (cur && guard++ < 10000) { chain.unshift(cur); cur = byId[cur.parent_message_uuid]; }
    return chain;
  }

  function collectUrls(obj, into, depth) {
    if (!obj || depth > 5) return;
    if (Array.isArray(obj)) { obj.forEach(function (x) { collectUrls(x, into, depth + 1); }); return; }
    if (typeof obj !== 'object') return;
    var url = obj.url || obj.uri || obj.source_url;
    if (typeof url === 'string' && /^https?:/i.test(url)) into.push({ url: url, title: obj.title || obj.name || obj.source || '' });
    Object.keys(obj).forEach(function (k) { if (obj[k] && typeof obj[k] === 'object') collectUrls(obj[k], into, depth + 1); });
  }

  // Render a tool's input readably: long/multiline strings (scripts, code,
  // commands, page text) become code blocks; short values stay inline.
  function renderToolInput(input, max) {
    if (input == null) return '';
    if (typeof input !== 'object') return fence(trim(String(input), max));
    var keys = Object.keys(input);
    if (!keys.length) return '_(no input)_';
    var inline = [], blocks = [];
    keys.forEach(function (k) {
      var v = input[k];
      if (typeof v === 'string' && (v.indexOf('\n') >= 0 || v.length > 160)) {
        var lang = /^(code|script|text|query)$/i.test(k) ? '' : '';
        if (/^(code|script)$/i.test(k)) lang = /^\s*(import |def |from |print\()/.test(v) ? 'python' : (/(const |function |=>|document\.)/.test(v) ? 'javascript' : '');
        if (/^command$/i.test(k)) lang = 'bash';
        blocks.push('`' + k + '`:\n' + fence(trim(v, max), lang));
      } else if (v !== null && typeof v === 'object') {
        var js = JSON.stringify(v, null, 2);
        if (js.length > 160) blocks.push('`' + k + '`:\n' + fence(trim(js, max), 'json'));
        else inline.push('`' + k + '`: ' + js.replace(/\n\s*/g, ' '));
      } else {
        inline.push('`' + k + '`: ' + String(v));
      }
    });
    return (inline.length ? inline.map(function (s) { return '- ' + s; }).join('\n') : '') +
      (inline.length && blocks.length ? '\n\n' : '') + blocks.join('\n\n');
  }

  function renderToolResult(block, max, sources) {
    var c = block.content;
    var parts = [];
    var links = [];
    if (typeof c === 'string') parts.push(fence(trim(c, max)));
    else if (Array.isArray(c)) {
      var textBuf = [];
      c.forEach(function (it) {
        if (!it || typeof it !== 'object') { textBuf.push(String(it)); return; }
        if (it.type === 'text' && typeof it.text === 'string') textBuf.push(it.text);
        else if (it.type === 'image') textBuf.push('[image / screenshot]');
        else if (it.type === 'knowledge' || it.url) {
          links.push({ url: it.url, title: it.title || '' });
          var snip = it.text || (it.metadata && it.metadata.text) || '';
          textBuf.push('- ' + (it.title || it.url) + (it.url ? ' (' + it.url + ')' : '') + (snip ? '\n  ' + trim(String(snip).replace(/\s+/g, ' '), 400) : ''));
        } else textBuf.push(JSON.stringify(it));
      });
      if (textBuf.length) parts.push(fence(trim(textBuf.join('\n'), max)));
    } else if (c != null) parts.push(fence(trim(JSON.stringify(c, null, 2), max), 'json'));
    collectUrls(block.content, links, 0);
    links.forEach(function (l) { sources.add(l.url, l.title); });
    return parts.join('\n\n') || '_(empty result)_';
  }

  /* Files in a Claude chat. Three kinds, all fetched from the user's own
   * signed-in tab:
   *  - files on a message (msg.files): what Claude sent (newer chats) or what
   *    you uploaded; /api/organizations/{org}/files/{id}/contents
   *  - files Claude presented from its sandbox (older chats, present_files):
   *    /api/organizations/{org}/conversations/{conv}/wiggle/download-file?path=
   *  - classic artifacts (tool "artifacts"): rebuilt from create/update/rewrite
   * Each file shows up in the Markdown as a token that is turned into a link
   * (or a plain name) once we know whether it was saved. */
  var ARTIFACT_EXT = {
    'text/markdown': 'md', 'text/html': 'html', 'image/svg+xml': 'svg',
    'application/vnd.ant.react': 'jsx', 'application/vnd.ant.mermaid': 'mmd'
  };
  var LANG_EXT = {
    python: 'py', javascript: 'js', typescript: 'ts', jsx: 'jsx', tsx: 'tsx', html: 'html', css: 'css',
    json: 'json', bash: 'sh', shell: 'sh', sh: 'sh', sql: 'sql', swift: 'swift', java: 'java', go: 'go',
    rust: 'rs', ruby: 'rb', php: 'php', c: 'c', cpp: 'cpp', csharp: 'cs', kotlin: 'kt', r: 'r',
    yaml: 'yml', xml: 'xml', markdown: 'md', vba: 'bas'
  };
  function baseName(p) { return String(p || '').split('/').pop() || 'file'; }
  function artifactFileName(a) {
    var ext = ARTIFACT_EXT[a.type] || (a.type === 'application/vnd.ant.code' ? LANG_EXT[(a.language || '').toLowerCase()] || 'txt' : 'txt');
    var t = String(a.title || a.id || 'artifact').trim();
    return /\.[a-z0-9]{1,5}$/i.test(t) ? t : t + '.' + ext;
  }

  async function exportClaude(opts) {
    var m = location.pathname.match(/\/chat\/([0-9a-f-]{36})/i);
    if (!m) throw new Error('Open a Claude chat (claude.ai/chat/...) first.');
    toast('loading the full conversation data...');
    var conv = await claudeFetchConversation(m[1]);
    var branch = claudeActiveBranch(conv);
    var full = opts.mode === 'full';
    var max = opts.maxToolChars || 0;
    var allSources = SourceList();
    var stats = { messages: 0, toolCalls: 0, thinking: 0, sources: 0 };
    var out = [];
    var turn = 0;

    var api = '/api/organizations/' + conv.__org;
    var files = [];            // { name, by: 'claude' | 'you', url | text, date }
    var byPath = {};           // sandbox path -> file (one entry; the server keeps only the last version)
    var artifacts = {};        // classic artifact id -> file
    var hosted = [];           // links to hosted artifacts (claude.ai/artifact/...)
    function token(f) { return '\u0000F' + files.indexOf(f) + '\u0000'; }
    function addFile(f) { files.push(f); return f; }
    function sandboxFile(path, date) {
      if (!byPath[path]) byPath[path] = addFile({
        name: baseName(path), by: 'claude', date: date,
        url: api + '/conversations/' + conv.uuid + '/wiggle/download-file?path=' + encodeURIComponent(path)
      });
      return byPath[path];
    }

    branch.forEach(function (msg) {
      var isUser = msg.sender === 'human';
      if (isUser) turn++;
      stats.messages++;
      var head = '## ' + (isUser ? 'You' : 'Claude') + ' (turn ' + turn + (msg.created_at ? ', ' + fmtDate(msg.created_at) : '') + ')';
      var body = [];
      var replySources = SourceList();
      var stepNo = 0;
      var toolNames = {};
      var toolInputs = {};
      var madeHere = [];       // files Claude made in this message, in order
      var hostedHere = [];
      function made(f) { if (madeHere.indexOf(f) < 0) madeHere.push(f); }

      (msg.content || []).forEach(function (b) {
        if (!b || !b.type) return;
        // Files and artifacts are collected whatever the export mode.
        if (b.type === 'tool_use' && !isUser) {
          var inp = b.input || {};
          toolInputs[b.id] = inp;
          if (b.name === 'present_files') (inp.filepaths || inp.files || []).forEach(function (p) { made(sandboxFile(p, msg.created_at)); });
          else if (b.name === 'create_file' && /^\/mnt\/user-data\/outputs\//.test(inp.path || '')) made(sandboxFile(inp.path, msg.created_at));
          else if (b.name === 'artifacts' && inp.id) {
            var a = artifacts[inp.id];
            var cmd = inp.command || 'create';
            if (!a) {
              a = artifacts[inp.id] = addFile({ by: 'claude', date: msg.created_at, text: '', meta: { id: inp.id } });
            }
            ['type', 'language', 'title'].forEach(function (k) { if (inp[k]) a.meta[k] = inp[k]; });
            a.name = artifactFileName(a.meta);
            if (cmd === 'update' && typeof inp.old_str === 'string') a.text = a.text.split(inp.old_str).join(inp.new_str || '');
            else if (typeof inp.content === 'string') a.text = inp.content;
            made(a);
          }
        }
        if (b.type === 'tool_result' && !isUser && /^Artifact$|claude-artifacts__(publish|edit|create)/.test(b.name || '')) {
          var act = (toolInputs[b.tool_use_id] || {}).action || '';
          if (!/^(read|list|get|describe|guide)/i.test(act)) {
            (JSON.stringify(b.content || '').match(/https:\/\/claude\.ai\/artifact\/[A-Za-z0-9_-]+/g) || []).forEach(function (u) {
              if (hosted.indexOf(u) < 0) hosted.push(u);
              if (hostedHere.indexOf(u) < 0) hostedHere.push(u);
            });
          }
        }
      });

      (msg.content || []).forEach(function (b) {
        if (!b || !b.type) return;
        if (b.type === 'text') {
          if (b.text && b.text.trim()) body.push(b.text.trim());
          var cites = [];
          collectUrls(b.citations, cites, 0);
          cites.forEach(function (s) { replySources.add(s.url, s.title); allSources.add(s.url, s.title); });
        } else if (b.type === 'thinking') {
          if (!full) return;
          var th = b.thinking || (b.summaries || []).map(function (s) { return s.summary || ''; }).join('\n');
          if (th && th.trim()) { stats.thinking++; body.push('**[Thinking]**\n\n' + quote(trim(th.trim(), max))); }
        } else if (b.type === 'tool_use') {
          if (!full) return;
          stepNo++; stats.toolCalls++;
          toolNames[b.id] = b.name;
          var desc = b.message || (b.display_content && b.display_content.text) || '';
          body.push('**[Step ' + stepNo + ': tool `' + (b.name || 'tool') + '`]**' + (desc ? ' ' + desc : '') +
            '\n\n' + renderToolInput(b.input, max));
        } else if (b.type === 'tool_result') {
          var res = renderToolResult(b, max, replySources);
          if (!full) return;
          var nm = b.name || toolNames[b.tool_use_id] || 'tool';
          body.push('**[Result of `' + nm + '`' + (b.is_error ? ', ERROR' : '') + ']**\n\n' + res);
        } else if (b.type === 'image') {
          body.push('[image]');
        } else if (full) {
          body.push('**[' + b.type + ']**\n\n' + fence(trim(JSON.stringify(b, null, 2), max), 'json'));
        }
      });

      replySources.items().forEach(function (s) { allSources.add(s.url, s.title); });

      // Files on the message itself: uploads on your messages, files Claude sent on its replies.
      var stored = (msg.files_v2 && msg.files_v2.length ? msg.files_v2 : msg.files) || [];
      var mine = [];
      stored.forEach(function (f) {
        var id = f.file_uuid || f.uuid;
        if (!id) return;
        var file = addFile({ name: f.file_name || 'file', by: isUser ? 'you' : 'claude', date: f.created_at || msg.created_at, url: api + '/files/' + id + '/contents' });
        if (isUser) mine.push(file); else made(file);
      });
      // Pasted text and older attachments: their text is in the conversation data.
      (msg.attachments || []).forEach(function (f) {
        if (!isUser || typeof f.extracted_content !== 'string') return;
        var nm = f.file_name || 'pasted text.txt';
        mine.push(addFile({ name: /\.[a-z0-9]{1,5}$/i.test(nm) ? nm : nm + '.txt', by: 'you', date: f.created_at || msg.created_at, text: f.extracted_content }));
        if (full) body.push('**[Attachment content: ' + nm + ']**\n\n' + fence(trim(f.extracted_content, max)));
      });
      if (mine.length) body.unshift('**Attached:** ' + mine.map(token).join(', '));
      if (madeHere.length) body.push('**Files it made:** ' + madeHere.map(token).join(', '));
      if (hostedHere.length) body.push('**Artifacts it published:** ' + hostedHere.map(function (u) { return '<' + u + '>'; }).join(', '));

      if (opts.includeSources && !isUser && replySources.items().length) {
        body.push('**Sources used in this reply:**\n\n' + replySources.md());
      }
      out.push(head + '\n\n' + (body.join('\n\n') || '_(no text)_'));
    });

    stats.sources = allSources.items().length;
    var tail = hosted.length
      ? '\n\n---\n\n## Artifacts published from this chat (' + hosted.length + ')\n\n' +
        hosted.map(function (u) { return '- <' + u + '>'; }).join('\n') +
        '\n\nThese live on claude.ai as their own pages, so they are linked here rather than saved.'
      : '';
    return {
      site: 'Claude',
      title: conv.name || document.title,
      model: conv.model || '',
      created: conv.created_at,
      body: out.join('\n\n---\n\n') + tail,
      sources: allSources,
      stats: stats,
      files: files
    };
  }

  // Fallback for Claude when the conversation data can't be loaded: read the
  // page (step summaries only, like what you see on screen).
  async function exportClaudeFromPage(opts) {
    var full = opts.mode === 'full';
    if (full) await expandMatching(document, /more steps|actions\)|used .* and|show (all|more)|expand/i, opts);
    var nodes = Array.prototype.slice.call(document.querySelectorAll('[data-testid="user-message"], [data-testid="assistant-message"]'));
    var out = [], turn = 0;
    nodes.forEach(function (n) {
      var isUser = n.getAttribute('data-testid') === 'user-message';
      if (isUser) turn++;
      var body = [];
      if (!isUser && full) {
        var steps = Array.prototype.slice.call(n.querySelectorAll('[data-step-key]')).map(textOf).filter(Boolean);
        if (steps.length) body.push('**[Steps shown on screen]**\n\n' + steps.map(function (s, i) { return (i + 1) + '. ' + s; }).join('\n'));
      }
      var replyParts = isUser ? [n] : Array.prototype.slice.call(n.querySelectorAll('[data-perf-reply-text]'));
      var txt = replyParts.map(function (p) { return htmlToMd(p); }).join('\n\n').trim();
      if (txt) body.push(txt);
      out.push('## ' + (isUser ? 'You' : 'Claude') + ' (turn ' + turn + ')\n\n' + (body.join('\n\n') || '_(no text)_'));
    });
    return { site: 'Claude (from page)', title: document.title, body: out.join('\n\n---\n\n'), sources: SourceList(), stats: { messages: nodes.length } };
  }

  /* ------------------------------------------------------------------ *
   * ChatGPT (on-screen)
   * ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ *
   * Shared: a list of files a chat made, with tokens for the Markdown
   * ------------------------------------------------------------------ */
  // f: { name, by: 'ai' | 'claude' | 'you', url | text, indirect?, headers?, nameFromServer?, date }
  //   indirect: the url answers JSON { download_url, file_name } (ChatGPT)
  function FileBag() {
    var list = [], byKey = {};
    return {
      list: list,
      add: function (f, key) {
        if (key && byKey[key]) return byKey[key];
        list.push(f);
        if (key) byKey[key] = f;
        return f;
      },
      get: function (key) { return byKey[key]; },
      tok: function (f) { return '\u0000F' + list.indexOf(f) + '\u0000'; },        // "[name](files/name)" or `name`
      pathTok: function (f) { return '\u0000P' + list.indexOf(f) + '\u0000'; }     // just the path, for links already in the text
    };
  }

  function noUtm(u) {
    return String(u || '').replace(/([?&])utm_source=chatgpt\.com(&|$)/, function (m, a, b) { return b ? a : ''; }).replace(/[?&]$/, '');
  }

  /* ------------------------------------------------------------------ *
   * ChatGPT: full conversation data (what the site itself loads)
   * ------------------------------------------------------------------ */
  var CANVAS_EXT = { document: 'md', 'code/python': 'py', 'code/javascript': 'js', 'code/typescript': 'ts', 'code/html': 'html',
    'code/react': 'jsx', 'code/css': 'css', 'code/java': 'java', 'code/cpp': 'cpp', 'code/go': 'go', 'code/rust': 'rs',
    'code/ruby': 'rb', 'code/php': 'php', 'code/swift': 'swift', 'code/kotlin': 'kt', 'code/sql': 'sql', 'code/bash': 'sh', 'code/json': 'json' };

  function gptCanvasName(title, type) {
    var t = String(title || 'canvas').trim();
    if (/\.[a-z0-9]{1,5}$/i.test(t)) return t;
    return t + '.' + (CANVAS_EXT[type] || (/^code\//.test(type || '') ? type.slice(5) : 'md'));
  }

  // Swap ChatGPT's citation markers for readable links, then drop leftovers.
  function gptCleanText(text, refs, sources) {
    var t = String(text || '');
    (refs || []).slice().sort(function (a, b) { return (b.start_idx || 0) - (a.start_idx || 0); }).forEach(function (r) {
      var mt = r && r.matched_text;
      if (!mt || !mt.trim()) return;
      var links = [];
      collectUrls(r.items || r.sources || r, links, 0);
      links.forEach(function (l) { sources.add(noUtm(l.url), l.title); });
      var rep = '';
      if (typeof r.alt === 'string' && r.alt.trim()) rep = r.alt;
      else if (links.length) rep = ' (' + links.slice(0, 3).map(function (l) { return '[' + (l.title || l.url).replace(/[\[\]]/g, '') + '](' + noUtm(l.url) + ')'; }).join(', ') + ')';
      t = t.split(mt).join(rep);
    });
    t = t.replace(/\uE200[^\uE201]*\uE201/g, '').replace(/[\uE000-\uF8FF]/g, '').replace(/[ \t]+\(\[/g, ' ([');
    return t.replace(/\((https?:[^)\s]+)\)/g, function (m, u) { return '(' + noUtm(u) + ')'; });
  }

  async function exportChatGPTData(opts) {
    var m = location.pathname.match(/\/c\/([0-9a-f-]{20,})/i);
    if (!m) throw new Error('open a ChatGPT chat first');
    var cid = m[1];
    toast('loading the full conversation data...');
    var session = await fetch('/api/auth/session', { credentials: 'include' }).then(function (r) { return r.ok ? r.json() : {}; }).catch(function () { return {}; });
    if (!session.accessToken) throw new Error('not signed in');
    var H = { Authorization: 'Bearer ' + session.accessToken };
    var r = await fetch('/backend-api/conversation/' + cid, { headers: H, credentials: 'include' });
    if (!r.ok) throw new Error('conversation data unavailable (' + r.status + ')');
    var conv = await r.json();

    // The branch on screen: from the current node up to the root.
    var chain = [], cur = conv.current_node, guard = 0;
    while (cur && conv.mapping[cur] && guard++ < 20000) { chain.unshift(conv.mapping[cur]); cur = conv.mapping[cur].parent; }

    // Canvas documents: the latest version of each, if the site gives them.
    var textdocs = {};
    try {
      var td = await fetch('/backend-api/conversation/' + cid + '/textdocs', { headers: H, credentials: 'include' });
      if (td.ok) (await td.json() || []).forEach(function (d) { if (d && d.id && (!textdocs[d.id] || (d.version || 0) >= (textdocs[d.id].version || 0))) textdocs[d.id] = d; });
    } catch (e) { /* rebuilt from the chat below */ }

    var full = opts.mode === 'full';
    var max = opts.maxToolChars || 0;
    var bag = FileBag();
    var allSources = SourceList();
    var stats = { messages: 0, toolCalls: 0, thinking: 0, sources: 0 };
    var out = [];
    var turnNo = 0;
    var model = '';
    var section = null;   // the ChatGPT section being built
    var canvasByName = {};

    function fileUrl(id) { return '/backend-api/files/download/' + id + '?conversation_id=' + cid + '&inline=false'; }
    function upload(att) {
      return bag.add({ name: att.name || 'file', by: 'you', url: fileUrl(att.id), indirect: true, headers: H }, att.id);
    }
    function aiImage(ptr, title) {
      var id = String(ptr).replace(/^[a-z-]+:\/\//i, '');
      return bag.add({ name: (title || 'image') + '.png', by: 'ai', url: fileUrl(id), indirect: true, headers: H, nameFromServer: true }, id);
    }
    function sandbox(path, msgId) {
      return bag.add({
        name: path.split('/').pop(), by: 'ai', indirect: true, headers: H,
        url: '/backend-api/conversation/' + cid + '/interpreter/download?message_id=' + msgId + '&sandbox_path=' + encodeURIComponent(path),
        origHref: 'sandbox:' + path
      }, 'sandbox:' + path);
    }
    function canvasFile(name, text, docId) {
      var key = 'canvas:' + (docId || name);
      var f = bag.get(key) || bag.add({ name: name, by: 'ai', text: '' }, key);
      if (typeof text === 'string') f.text = text;
      return f;
    }
    function startAi() {
      if (section) return section;
      section = { body: [], sources: SourceList(), made: [], step: 0, tools: {} };
      return section;
    }
    function flush() {
      if (!section) return;
      stats.messages++;
      var s = section;
      section = null;
      if (s.made.length) s.body.push('**Files it made:** ' + s.made.map(bag.tok).join(', '));
      if (opts.includeSources && s.sources.items().length) s.body.push('**Sources used in this reply:**\n\n' + s.sources.md());
      s.sources.items().forEach(function (x) { allSources.add(x.url, x.title); });
      out.push('## ChatGPT (turn ' + turnNo + ')\n\n' + (s.body.join('\n\n') || '_(no text)_'));
    }
    function made(f) { var s = startAi(); if (s.made.indexOf(f) < 0) s.made.push(f); }
    function partsText(c) {
      return (c.parts || []).map(function (p) { return typeof p === 'string' ? p : ''; }).join('\n').trim();
    }

    chain.forEach(function (node) {
      var msg = node.message;
      if (!msg || !msg.content) return;
      var role = msg.author && msg.author.role;
      var c = msg.content;
      var ct = c.content_type;
      var md = msg.metadata || {};
      if (role === 'system' || /editable_context$/.test(ct || '')) return;

      if (role === 'user') {
        if (md.is_visually_hidden_from_conversation) return;
        flush();
        turnNo++;
        stats.messages++;
        var ub = [];
        var att = (md.attachments || []).map(upload);
        (c.parts || []).forEach(function (p) { if (p && p.asset_pointer) { var id = String(p.asset_pointer).replace(/^[a-z-]+:\/\//i, ''); if (!bag.get(id)) att.push(bag.add({ name: 'image.png', by: 'you', url: fileUrl(id), indirect: true, headers: H, nameFromServer: true }, id)); } });
        if (att.length) ub.push('**Attached:** ' + att.map(bag.tok).join(', '));
        var ut = partsText(c);
        if (ut) ub.push(ut);
        out.push('## You (turn ' + turnNo + (msg.create_time ? ', ' + fmtDate(new Date(msg.create_time * 1000).toISOString()) : '') + ')\n\n' + (ub.join('\n\n') || '_(no text)_'));
        return;
      }

      var s = startAi();
      if (role === 'assistant') {
        if (md.model_slug) model = md.model_slug;
        var to = msg.recipient || 'all';
        if (ct === 'thoughts') {
          if (!full) return;
          (c.thoughts || []).forEach(function (th) {
            var txt = [th.summary ? '**' + th.summary + '**' : '', th.content || ''].filter(Boolean).join('\n\n').trim();
            if (txt) { stats.thinking++; s.body.push('**[Thinking]**\n\n' + quote(trim(txt, max))); }
          });
        } else if (ct === 'reasoning_recap') {
          if (full && c.content) s.body.push('_' + c.content + '_');
        } else if (to === 'all' && (ct === 'text' || ct === 'multimodal_text')) {
          var txt = gptCleanText(partsText(c), md.content_references, s.sources);
          (md.citations || []).forEach(function (ci) { var mm = ci.metadata || ci; if (mm.url) s.sources.add(noUtm(mm.url), mm.title); });
          // Links to files from its code runs ("sandbox:/mnt/data/x.xlsx").
          txt = txt.replace(/sandbox:(\/mnt\/data\/[^)\s\]]+)/g, function (all, p) {
            var path = decodeURIComponent(p);
            var f = sandbox(path, msg.id);
            made(f);
            return bag.pathTok(f);
          });
          if (txt) s.body.push(txt);
        } else if (/^canmore\./.test(to)) {
          // Canvas: create_textdoc {name, type, content}, update_textdoc {updates:[{pattern, replacement, multiple}]}
          var inp = {};
          try { inp = JSON.parse(c.text || partsText(c) || '{}'); } catch (e) { /* not JSON */ }
          var f = null;
          if (/create_textdoc/.test(to) && inp.name) {
            f = canvasFile(gptCanvasName(inp.name, inp.type), inp.content || '', null);
            canvasByName.last = f;
          } else if (/update_textdoc/.test(to) && canvasByName.last) {
            f = canvasByName.last;
            (inp.updates || []).forEach(function (u) {
              try { f.text = f.text.replace(new RegExp(u.pattern, u.multiple ? 'g' : ''), u.replacement); } catch (e) { /* bad pattern */ }
            });
          }
          if (f) made(f);
          if (full) { s.step++; stats.toolCalls++; s.body.push('**[Step ' + s.step + ': canvas `' + to.replace(/^canmore\./, '') + '`]**\n\n' + renderToolInput(inp, max)); }
        } else if (to !== 'all') {
          if (!full) return;
          var code = c.text != null ? c.text : partsText(c);
          if (!String(code).trim()) return;
          s.step++; stats.toolCalls++;
          var nm = to === 'python' ? 'python' : to;
          var lang = to === 'python' ? 'python' : (/^\s*[{[]/.test(code) ? 'json' : '');
          s.body.push('**[Step ' + s.step + ': tool `' + nm + '`]**\n\n' + fence(trim(code, max), lang));
        }
        return;
      }

      if (role === 'tool') {
        var tname = (msg.author && msg.author.name) || 'tool';
        // Search results feed the sources whatever the mode.
        (md.search_result_groups || []).forEach(function (g) { (g.entries || []).forEach(function (e) { if (e.url) s.sources.add(noUtm(e.url), e.title); }); });
        // Pictures it generated or charts its code drew.
        (c.parts || []).forEach(function (p) { if (p && p.asset_pointer) made(aiImage(p.asset_pointer, md.image_gen_title)); });
        ((md.aggregate_result && md.aggregate_result.messages) || []).forEach(function (am) {
          if (am && am.image_url) made(aiImage(am.image_url, 'chart'));
        });
        if (!full) return;
        var res = '';
        if (ct === 'execution_output') res = c.text || '';
        else if (ct === 'tether_browsing_display') res = [c.summary, c.result].filter(Boolean).join('\n\n');
        else if (ct === 'tether_quote') res = [c.title, c.url, c.text].filter(Boolean).join('\n');
        else res = partsText(c) || (c.text || '');
        res = String(res).trim();
        if (!res) return;
        s.body.push('**[Result of `' + tname + '`]**\n\n' + fence(trim(res, max)));
      }
    });
    flush();

    // Canvas documents the site handed back whole (newest version) win over our rebuild.
    Object.keys(textdocs).forEach(function (id) {
      var d = textdocs[id];
      var nm = gptCanvasName(d.title, d.textdoc_type);
      var existing = bag.list.filter(function (f) { return f.name === nm && typeof f.text === 'string'; })[0];
      if (existing) existing.text = d.content || existing.text;
      else bag.add({ name: nm, by: 'ai', text: d.content || '' }, 'canvas:' + id);
    });

    stats.sources = allSources.items().length;
    return { site: 'ChatGPT', title: conv.title || document.title, model: model, body: out.join('\n\n---\n\n'), sources: allSources, stats: stats, files: bag.list };
  }

  async function exportChatGPT(opts) {
    try { return await exportChatGPTData(opts); }
    catch (e) {
      toast('full data unavailable, reading the page instead...');
      var res = await exportChatGPTFromPage(opts);
      res.warning = e.message;
      return res;
    }
  }

  async function exportChatGPTFromPage(opts) {
    var full = opts.mode === 'full';
    var allSources = SourceList();
    var turns = Array.prototype.slice.call(document.querySelectorAll('[data-turn-key]'));
    if (!turns.length) turns = Array.prototype.slice.call(document.querySelectorAll('[data-message-author-role]'));
    var out = [], n = 0, turnNo = 0;

    for (var i = 0; i < turns.length; i++) {
      var t = turns[i];
      toast('reading turn ' + (i + 1) + ' of ' + turns.length + '...');
      if (full) await expandMatching(t, /^(thought|thinking|reasoned|worked|searched|searching|analy[sz]ed|ran|used)\b/i, opts);

      var userEl = t.querySelector('[data-user-message-bubble]') ||
        (t.getAttribute('data-message-author-role') === 'user' ? t : null);
      if (userEl) {
        turnNo++;
        out.push('## You (turn ' + turnNo + ')\n\n' + (htmlToMd(userEl) || '_(no text)_'));
      }

      var mains = Array.prototype.slice.call(t.querySelectorAll('[data-markdown-text-style="assistant-message"], .markdown'));
      if (!mains.length && t.getAttribute('data-message-author-role') === 'assistant') mains = [t];
      if (!mains.length) continue;
      n++;
      var replySources = SourceList();
      var body = [];

      if (full) {
        var unit = mains[0].closest('[data-chatgpt-search-unit-key], [data-message-author-role]') || t;
        var work = extraWorkText(unit, mains, '.turn-action-controls, [data-user-message-bubble], h4');
        if (work) body.push('**[Thinking / work shown by ChatGPT]**\n\n' + quote(trim(work, opts.maxToolChars)));
      }
      body.push(mains.map(function (m) { return htmlToMd(m); }).join('\n\n'));

      allLinks(t).forEach(function (a) { if (!isChromeLink(a)) replySources.add(a.href, textOf(a)); });
      if (opts.includeSources) {
        var srcBtns = Array.prototype.slice.call(t.querySelectorAll('button[aria-label="Sources"], button')).filter(function (b) {
          return /^sources$/i.test((b.getAttribute('aria-label') || textOf(b)).trim());
        });
        for (var k = 0; k < srcBtns.length; k++) await clickAndHarvest(srcBtns[k], replySources, opts);
        if (replySources.items().length) body.push('**Sources used in this reply:**\n\n' + replySources.md());
      }
      replySources.items().forEach(function (s) { allSources.add(s.url, s.title); });
      out.push('## ChatGPT (turn ' + turnNo + ')\n\n' + body.join('\n\n'));
    }
    return { site: 'ChatGPT', title: document.title, body: out.join('\n\n---\n\n'), sources: allSources, stats: { replies: n } };
  }

  /* ------------------------------------------------------------------ *
   * Gemini (on-screen)
   * ------------------------------------------------------------------ */
  async function geminiLoadAll(opts) {
    // Gemini lazy-loads older turns when you scroll up.
    var scroller = document.querySelector('infinite-scroller.chat-history, [data-test-id="chat-history-container"]');
    if (!scroller) return;
    var last = -1;
    for (var i = 0; i < 40; i++) {
      var count = document.querySelectorAll('user-query').length;
      if (count === last) break;
      last = count;
      scroller.scrollTop = 0;
      toast('loading earlier messages (' + count + ')...');
      await sleep(900, opts);
    }
  }

  /* ------------------------------------------------------------------ *
   * Gemini: full conversation data (the same internal call the page uses)
   * ------------------------------------------------------------------ */
  // Arrays shaped [null, n, "name.ext", "https://..."] are files (uploads, generated pictures).
  function geminiFileRefs(node, into, depth) {
    if (!Array.isArray(node) || depth > 14) return into;
    if (node.length >= 4 && node[0] === null && typeof node[2] === 'string' && typeof node[3] === 'string' && /^https:\/\//.test(node[3]) && /\.[A-Za-z0-9]{2,5}$/.test(node[2])) {
      if (!into.some(function (x) { return x.url === node[3]; })) into.push({ name: node[2], url: node[3] });
      return into;
    }
    node.forEach(function (x) { geminiFileRefs(x, into, depth + 1); });
    return into;
  }

  async function geminiLoadData(convId, prefix) {
    var html = await fetch(prefix + '/app', { credentials: 'include' }).then(function (r) { return r.text(); });
    function val(k) { var m = html.match(new RegExp('"' + k + '":"([^"]*)"')); return m ? m[1] : ''; }
    var at = val('SNlM0e'), bl = val('cfb2h'), sid = val('FdrFJe');
    if (!at) throw new Error('not signed in');
    var req = JSON.stringify([[['hNvQHb', JSON.stringify(['c_' + convId, 1000, null, 1, [0], [4], null, 1]), null, 'generic']]]);
    var qs = new URLSearchParams({ rpcids: 'hNvQHb', 'source-path': location.pathname, bl: bl, 'f.sid': sid, hl: 'en', _reqid: String(100000 + Math.floor(Math.random() * 800000)), rt: 'c' });
    var r = await fetch(prefix + '/_/BardChatUi/data/batchexecute?' + qs, {
      method: 'POST', credentials: 'include',
      headers: { 'content-type': 'application/x-www-form-urlencoded;charset=UTF-8' },
      body: new URLSearchParams({ 'f.req': req, at: at })
    });
    if (!r.ok) throw new Error('conversation data unavailable (' + r.status + ')');
    var text = await r.text();
    var lines = text.split('\n');
    for (var i = 0; i < lines.length; i++) {
      if (lines[i].indexOf('[[') !== 0) continue;
      try {
        var arr = JSON.parse(lines[i]);
        for (var k = 0; k < arr.length; k++) if (arr[k][0] === 'wrb.fr' && arr[k][1] === 'hNvQHb' && arr[k][2]) return JSON.parse(arr[k][2]);
      } catch (e) { /* next line */ }
    }
    throw new Error('conversation data not understood');
  }

  async function exportGeminiData(opts) {
    var m = location.pathname.match(/^(\/u\/\d+)?\/(?:app|gem\/[^/]+)\/([0-9a-f]{8,})/i);
    if (!m) throw new Error('open a Gemini chat first');
    var prefix = m[1] || '';
    toast('loading the full conversation data...');
    var data = await geminiLoadData(m[2], prefix);
    var turns = (data && data[0]) || [];
    if (!turns.length) throw new Error('no messages in the conversation data');
    turns = turns.slice().sort(function (a, b) { return ((a[4] || [])[0] || 0) - ((b[4] || [])[0] || 0); });

    var full = opts.mode === 'full';
    var max = opts.maxToolChars || 0;
    var bag = FileBag();
    var allSources = SourceList();
    var stats = { messages: 0, toolCalls: 0, thinking: 0, sources: 0 };
    var out = [];

    // Pictures already shown on the page: a backup copy if the original can't be downloaded.
    var domReplies = Array.prototype.slice.call(document.querySelectorAll('model-response'));

    turns.forEach(function (t, idx) {
      var turnNo = idx + 1;
      var when = t[4] && t[4][0] ? ', ' + fmtDate(new Date(t[4][0] * 1000).toISOString()) : '';
      // You
      var q = (t[2] && t[2][0]) || [];
      var ub = [];
      var ups = geminiFileRefs(q.slice(1), [], 0).map(function (f) {
        return bag.add({ name: f.name, by: 'you', url: f.url }, f.url);
      });
      if (ups.length) ub.push('**Attached:** ' + ups.map(bag.tok).join(', '));
      if (typeof q[0] === 'string' && q[0].trim()) ub.push(q[0].trim());
      stats.messages++;
      out.push('## You (turn ' + turnNo + when + ')\n\n' + (ub.join('\n\n') || '_(no text)_'));

      // Gemini (the reply that was picked when there were drafts)
      var cands = (t[3] && t[3][0]) || [];
      var chosen = t[3] && t[3][3];
      var cand = cands.filter(function (c) { return c && c[0] === chosen; })[0] || cands[0];
      if (!cand) return;
      stats.messages++;
      var body = [];
      var srcs = SourceList();

      var thought = cand[37] && cand[37][0] && cand[37][0][0];
      if (full && typeof thought === 'string' && thought.trim()) { stats.thinking++; body.push('**[Thinking]**\n\n' + quote(trim(thought.trim(), max))); }

      // Sources: [url, title, favicon, snippet, ..., site]
      ((cand[2] && cand[2][1]) || []).forEach(function (c) {
        ((c && c[2]) || []).forEach(function (s) { if (s && typeof s[0] === 'string') srcs.add(s[0].replace(/#:~:text=.*$/, ''), s[1] || s[6] || ''); });
      });

      // Pictures it generated: matched in order to the placeholders in the reply.
      var pics = geminiFileRefs(cand[12] || [], [], 0);
      var dom = domReplies.length ? domReplies[domReplies.length - (turns.length - idx)] : null;
      var domImgs = dom ? Array.prototype.slice.call(dom.querySelectorAll('generated-image img, single-image img.image')).map(function (im) { return im.currentSrc || im.src; }) : [];
      var made = pics.map(function (p, i) {
        return bag.add({ name: p.name, by: 'ai', url: p.url, altUrl: domImgs[i] || '' }, p.url);
      });

      // Canvas documents (memos, code, HTML slides): title, file name and full content sit in cand[30].
      var canv = ((cand[30] || []).filter(Array.isArray)).map(function (c, k) {
        var nm = typeof c[9] === 'string' && c[9] ? c[9] : String(c[0] || 'canvas').replace(/^c_[0-9a-f]+_/i, '');
        var versions = Array.isArray(c[19]) ? c[19].filter(function (x) { return typeof x === 'string' && x.trim(); }) : [];
        var structured = c[8] && c[8][0] && c[8][0][0] && c[8][0][0][3] && c[8][0][0][3][0];
        var content = versions.length ? versions[versions.length - 1]
          : (typeof structured === 'string' && structured.trim() ? structured : String(c[4] || '').replace(/^```[a-z]*\n/i, '').replace(/\n```\s*$/, ''));
        if (!/\.[A-Za-z0-9]{1,6}$/.test(nm)) nm += /<!doctype|<html/i.test(content) ? '.html' : '.md';
        var f = bag.add({ name: nm, by: 'ai', text: content, title: c[2] || nm }, 'canvas:' + (c[1] || k) + ':' + idx);
        made.push(f);
        return f;
      });

      var text = String((cand[1] && cand[1][0]) || '');
      var picNo = 0;
      text = text.replace(/https?:\/\/googleusercontent\.com\/image_generation_content\/\d+/g, function () {
        var f = made[picNo++];
        return f ? '![' + f.name.replace(/[\[\]]/g, '') + '](' + bag.pathTok(f) + ')' : '';
      }).replace(/https?:\/\/googleusercontent\.com\/immersive_entry_chip\/(\d+)/g, function (all, n) {
        var f = canv[+n] || canv[0];
        return f ? '**Canvas: ' + String(f.title).replace(/[\[\]*]/g, '') + '** (' + bag.tok(f) + ')' : all;
      }).replace(/https?:\/\/googleusercontent\.com\/([a-z_]+?)(?:_content|_chip)?\/\d+/g, function (all, kind) {
        var names = { immersive_entry: 'canvas', immersive: 'canvas', youtube: 'YouTube video', map: 'map', flight: 'flights', hotel: 'hotels' };
        return '_[Gemini ' + (names[kind] || kind.replace(/_/g, ' ')) + ' shown here]_';
      }).trim();
      made.forEach(function (f) { f.origHref = f.altUrl || f.url; });
      if (text) body.push(text);
      if (made.length) body.push('**Files it made:** ' + made.map(bag.tok).join(', '));
      if (opts.includeSources && srcs.items().length) body.push('**Sources used in this reply:**\n\n' + srcs.md());
      srcs.items().forEach(function (x) { allSources.add(x.url, x.title); });
      out.push('## Gemini (turn ' + turnNo + when + ')\n\n' + (body.join('\n\n') || '_(no text)_'));
    });

    stats.sources = allSources.items().length;
    return { site: 'Gemini', title: document.title, body: out.join('\n\n---\n\n'), sources: allSources, stats: stats, files: bag.list };
  }

  async function exportGemini(opts) {
    try {
      // Rendered pictures are the backup for generated images, so load the turns first.
      if (opts.withFiles) await geminiLoadAll(opts);
      return await exportGeminiData(opts);
    } catch (e) {
      toast('full data unavailable, reading the page instead...');
      var res = await exportGeminiFromPage(opts);
      res.warning = e.message;
      return res;
    }
  }

  async function exportGeminiFromPage(opts) {
    var full = opts.mode === 'full';
    await geminiLoadAll(opts);
    var allSources = SourceList();
    var queries = Array.prototype.slice.call(document.querySelectorAll('user-query'));
    var responses = Array.prototype.slice.call(document.querySelectorAll('model-response'));
    var items = queries.map(function (q) { return { el: q, user: true }; })
      .concat(responses.map(function (r) { return { el: r, user: false }; }))
      .sort(function (a, b) { return a.el.compareDocumentPosition(b.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1; });
    var out = [], turn = 0;
    var bag = FileBag(), imgNo = 0;

    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      if (it.user) {
        turn++;
        var qt = it.el.querySelector('.query-text') || it.el;
        out.push('## You (turn ' + turn + ')\n\n' + (htmlToMd(qt) || '_(no text)_'));
        continue;
      }
      toast('reading Gemini reply ' + turn + '...');
      var r = it.el;
      var body = [];
      var main = r.querySelector('message-content .markdown, message-content') || r;
      if (full) {
        await expandMatching(r, /show thinking|thinking|thoughts/i, opts);
        var thoughts = r.querySelector('model-thoughts, [class*="thoughts-content"], [class*="thoughts-container"], thinking-overlay');
        var thinkText = thoughts ? (thoughts.innerText || thoughts.textContent || '').trim() : '';
        if (!thinkText) thinkText = extraWorkText(r, [main], 'message-actions, sources-list, .response-footer, .response-container-header');
        thinkText = thinkText.replace(/^(show|hide) thinking\s*/i, '').trim();
        if (thinkText.length > 15) body.push('**[Thinking shown by Gemini]**\n\n' + quote(trim(thinkText, opts.maxToolChars)));
      }
      var replyMd = htmlToMd(main);
      // Pictures Gemini generated: already loaded in the page, saved as files.
      var made = [];
      Array.prototype.slice.call(r.querySelectorAll('generated-image img, single-image img.image')).forEach(function (im) {
        var src = im.currentSrc || im.src;
        if (!src || /^data:image\/svg/.test(src)) return;
        var f = bag.get(src) || bag.add({ name: 'Gemini image ' + (++imgNo) + '.png', by: 'ai', url: src, origHref: src }, src);
        if (made.indexOf(f) < 0) made.push(f);
        replyMd = replyMd.split(src).join(bag.pathTok(f));
      });
      body.push(replyMd);
      if (made.length) body.push('**Files it made:** ' + made.map(bag.tok).join(', '));
      var replySources = SourceList();
      allLinks(r).forEach(function (a) { if (!isChromeLink(a)) replySources.add(a.href, textOf(a)); });
      if (opts.includeSources) {
        var chips = Array.prototype.slice.call(r.querySelectorAll('button[aria-label^="View source details"], .source-inline-chip-container button')).slice(0, 30);
        var footerBtns = Array.prototype.slice.call(r.querySelectorAll('sources-list button, .response-footer button')).filter(function (b) { return /source/i.test((b.getAttribute('aria-label') || '') + textOf(b)); });
        var btns = footerBtns.concat(chips);
        for (var k = 0; k < btns.length; k++) await clickAndHarvest(btns[k], replySources, opts);
        if (replySources.items().length) body.push('**Sources used in this reply:**\n\n' + replySources.md());
      }
      replySources.items().forEach(function (s) { allSources.add(s.url, s.title); });
      out.push('## Gemini (turn ' + turn + ')\n\n' + body.join('\n\n'));
    }
    return { site: 'Gemini', title: document.title, body: out.join('\n\n---\n\n'), sources: allSources, stats: { turns: turn }, files: bag.list };
  }

  /* ------------------------------------------------------------------ *
   * Grok (on-screen)
   * ------------------------------------------------------------------ */
  /* ------------------------------------------------------------------ *
   * Grok: full conversation data (what grok.com itself loads)
   * ------------------------------------------------------------------ */
  function grokArgs(text) {
    var m = String(text || '').match(/<xai:tool_args><!\[CDATA\[([\s\S]*?)\]\]><\/xai:tool_args>/);
    if (!m) return null;
    try { var j = JSON.parse(m[1]); return j.args || j; } catch (e) { return m[1]; }
  }

  async function exportGrokData(opts) {
    var m = location.pathname.match(/\/c\/([0-9a-f-]{36})/i);
    if (!m || !/(^|\.)grok\.com$/.test(location.hostname)) throw new Error('open a Grok chat on grok.com first');
    var cid = m[1];
    toast('loading the full conversation data...');
    var base = '/rest/app-chat/conversations/' + cid;
    var nodesRes = await fetch(base + '/response-node?includeThreads=true', { credentials: 'include' });
    if (!nodesRes.ok) throw new Error('conversation data unavailable (' + nodesRes.status + ')');
    var nodes = (await nodesRes.json()).responseNodes || [];
    if (!nodes.length) throw new Error('no messages in the conversation data');
    var lr = await fetch(base + '/load-responses', {
      method: 'POST', credentials: 'include', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ responseIds: nodes.map(function (n) { return n.responseId; }) })
    });
    if (!lr.ok) throw new Error('conversation data unavailable (' + lr.status + ')');
    var responses = (await lr.json()).responses || [];
    var byId = {};
    responses.forEach(function (r) { byId[r.responseId] = r; });

    // The branch on screen: follow parents up from the last message.
    var chain = [], cur = byId[nodes[nodes.length - 1].responseId], guard = 0;
    while (cur && guard++ < 10000) { chain.unshift(cur); cur = byId[cur.parentResponseId]; }

    var title = document.title;
    try {
      var meta = await fetch(base, { credentials: 'include' }).then(function (r) { return r.ok ? r.json() : null; });
      if (meta && meta.title) title = meta.title;
    } catch (e) { /* keep the tab title */ }

    var full = opts.mode === 'full';
    var max = opts.maxToolChars || 0;
    var bag = FileBag();
    var allSources = SourceList();
    var stats = { messages: 0, toolCalls: 0, thinking: 0, sources: 0 };
    var out = [];
    var turn = 0;
    var model = '';

    chain.forEach(function (r) {
      var isUser = r.sender === 'human' || r.sender === 'user';
      if (isUser) turn++;
      stats.messages++;
      var body = [];
      var srcs = SourceList();
      if (!isUser && r.model) model = r.model;

      // Inline citations: <grok:render card_id="x" ...>...</grok:render> -> link from the card list.
      var cards = {};
      (r.cardAttachmentsJson || []).forEach(function (cj) { try { var c = JSON.parse(cj); if (c.id) cards[c.id] = c; } catch (e) { /* skip */ } });
      var text = String(r.message || '').replace(/<grok:render\b[^>]*card_id="([^"]+)"[^>]*>[\s\S]*?<\/grok:render>/g, function (all, id) {
        var c = cards[id];
        if (!c || !c.url) return '';
        srcs.add(c.url, c.title || '');
        return ' ([' + (c.title || c.url.replace(/^https?:\/\/(www\.)?/, '').split('/')[0]).replace(/[\[\]]/g, '') + '](' + c.url + '))';
      }).replace(/<\/?grok:[^>]*>/g, '').replace(/[ \t]+\(\[/g, ' ([').trim();

      if (!isUser && full) {
        var stepNo = 0;
        var results = {};
        (r.steps || []).forEach(function (st) {
          (st.toolUsageResults || []).forEach(function (u) { results[u.toolUsageCardId] = u; });
        });
        (r.steps || []).forEach(function (st) {
          var tags = st.tags || [];
          var stext = (st.text || []).join('\n').trim();
          if (tags.indexOf('tool_usage_card') >= 0) {
            (st.toolUsageCards || [{}]).forEach(function (card) {
              stepNo++; stats.toolCalls++;
              var nm = (stext.match(/<xai:tool_name>([^<]+)<\/xai:tool_name>/) || [])[1] || Object.keys(card).filter(function (k) { return k !== 'toolUsageCardId'; })[0] || 'tool';
              var args = grokArgs(stext) || (card[Object.keys(card).filter(function (k) { return k !== 'toolUsageCardId'; })[0]] || {}).args;
              body.push('**[Step ' + stepNo + ': tool `' + nm + '`]**\n\n' + renderToolInput(args, max));
              var res = results[card.toolUsageCardId];
              if (res) {
                var lines = [];
                var hits = (res.webSearchResults && res.webSearchResults.results) || [];
                hits.forEach(function (h) { lines.push('- ' + (h.title || h.url) + (h.url ? ' (' + h.url + ')' : '') + (h.preview ? '\n  ' + trim(String(h.preview).replace(/\s+/g, ' '), 300) : '')); srcs.add(h.url, h.title); });
                var other = JSON.parse(JSON.stringify(res));
                delete other.toolUsageCardId; delete other.webSearchResults;
                if (!lines.length && Object.keys(other).length) lines.push(trim(JSON.stringify(other, null, 2), max || 4000));
                if (lines.length) body.push('**[Result of `' + nm + '`]**\n\n' + fence(trim(lines.join('\n'), max)));
              }
            });
          } else if (tags.indexOf('header') >= 0 || tags.indexOf('raw_function_result') >= 0) {
            /* labels only */
          } else if (stext) {
            stats.thinking++;
            body.push('**[Thinking]**\n\n' + quote(trim(stext.replace(/<\/?xai:[^>]*>/g, ''), max)));
          }
        });
      }
      if (r.thinkingTrace && full) { stats.thinking++; body.push('**[Thinking]**\n\n' + quote(trim(r.thinkingTrace, max))); }

      (r.webSearchResults || []).concat(r.citedWebSearchResults || []).forEach(function (h) { if (h && h.url) srcs.add(h.url, h.title); });

      // Pictures it generated or edited.
      var made = [];
      (r.generatedImageUrls || []).concat(r.imageEditUris || []).forEach(function (u, i) {
        if (!u) return;
        var url = /^https?:/.test(u) ? u : 'https://assets.grok.com/' + String(u).replace(/^\//, '');
        made.push(bag.add({ name: 'Grok image ' + (bag.list.length + 1) + (/\.(png|jpe?g|webp|gif)$/i.test(url) ? url.match(/\.(png|jpe?g|webp|gif)$/i)[0] : '.jpg'), by: 'ai', url: url }, url));
      });

      if (text) body.push(text);
      if (made.length) body.push('**Files it made:** ' + made.map(bag.tok).join(', '));
      var att = (r.fileAttachmentsMetadata || []).map(function (f) { return f && (f.fileName || f.name); }).filter(Boolean);
      if (att.length) body.unshift('**Attached:** ' + att.map(function (n) { return '`' + n + '`'; }).join(', '));
      if (opts.includeSources && !isUser && srcs.items().length) body.push('**Sources used in this reply:**\n\n' + srcs.md());
      srcs.items().forEach(function (x) { allSources.add(x.url, x.title); });
      var when = r.createTime ? ', ' + fmtDate(r.createTime) : '';
      out.push('## ' + (isUser ? 'You' : 'Grok') + ' (turn ' + turn + when + ')\n\n' + (body.join('\n\n') || '_(no text)_'));
    });

    stats.sources = allSources.items().length;
    return { site: 'Grok', title: title, model: model, body: out.join('\n\n---\n\n'), sources: allSources, stats: stats, files: bag.list };
  }

  async function exportGrok(opts) {
    try { return await exportGrokData(opts); }
    catch (e) {
      toast('full data unavailable, reading the page instead...');
      var res = await exportGrokFromPage(opts);
      res.warning = e.message;
      return res;
    }
  }

  async function exportGrokFromPage(opts) {
    var full = opts.mode === 'full';
    var allSources = SourceList();
    var rows = Array.prototype.slice.call(document.querySelectorAll('[id^="response-"]'));
    var out = [], turn = 0;
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var cls = r.getAttribute('class') || '';
      var isUser = /\bitems-end\b/.test(cls);
      var main = r.querySelector('.response-content-markdown') || r.querySelector('.message-bubble') || r;
      if (isUser) {
        turn++;
        out.push('## You (turn ' + turn + ')\n\n' + (htmlToMd(main) || '_(no text)_'));
        continue;
      }
      toast('reading Grok reply ' + turn + '...');
      var body = [];
      if (full) {
        var tc = r.querySelector('.thinking-container, [class*="thinking-container"]');
        if (tc) {
          await expandMatching(tc, /worked for|thought for|thinking|reasoning/i, opts);
          var th = extraWorkText(tc, [], '');
          th = th.replace(/^(worked|thought) for [^\n]*\n?/i, '').trim();
          if (th.length > 15) body.push('**[Thinking / work shown by Grok]**\n\n' + quote(trim(th, opts.maxToolChars)));
        }
      }
      body.push(htmlToMd(main));
      var replySources = SourceList();
      allLinks(r).forEach(function (a) { if (!isChromeLink(a)) replySources.add(a.href, textOf(a)); });
      if (opts.includeSources) {
        var sb = Array.prototype.slice.call(r.querySelectorAll('button')).filter(function (b) { return /^\d+\s+sources?$/i.test(textOf(b)); });
        for (var k = 0; k < sb.length; k++) await clickAndHarvest(sb[k], replySources, opts);
        if (replySources.items().length) body.push('**Sources used in this reply:**\n\n' + replySources.md());
      }
      replySources.items().forEach(function (s) { allSources.add(s.url, s.title); });
      out.push('## Grok (turn ' + turn + ')\n\n' + body.join('\n\n'));
    }
    return { site: 'Grok', title: document.title, body: out.join('\n\n---\n\n'), sources: allSources, stats: { turns: turn } };
  }

  /* ------------------------------------------------------------------ *
   * Any other AI chat (Copilot, Le Chat,
   * Poe, Meta AI, HuggingChat, Kimi, Qwen, Open WebUI, LibreChat, agent
   * panels in web apps...). No site-specific code: it finds the messages
   * and works out who said what.
   *
   *  1. Role labels. Most chat apps mark each message with an attribute or
   *     class such as data-message-author-role="assistant", data-role="user",
   *     class "user-message" / "bot-message", aria-label "Your message".
   *  2. Layout, when nothing is labelled: the repeated blocks inside the chat
   *     scroller; messages pushed to the right (or in a bubble) are yours,
   *     the rest are the AI's.
   *  Long chats that only keep the visible messages on the page are read by
   *  scrolling the chat from top to bottom.
   * ------------------------------------------------------------------ */
  var KNOWN_AI_HOSTS = [
    [/(^|\.)tracelight\.ai$/, 'Tracelight'], [/(^|\.)perplexity\.ai$/, 'Perplexity'], [/(^|\.)deepseek\.com$/, 'DeepSeek'],
    [/(^|\.)mistral\.ai$/, 'Le Chat'], [/copilot\.microsoft\.com$|(^|\.)copilot\.cloud\.microsoft$|m365\.cloud\.microsoft$/, 'Copilot'],
    [/(^|\.)poe\.com$/, 'Poe'], [/(^|\.)meta\.ai$/, 'Meta AI'], [/^huggingface\.co$/, 'HuggingChat'], [/(^|\.)kimi\.(com|ai)$|(^|\.)moonshot\.cn$/, 'Kimi'],
    [/(^|\.)qwen\.ai$|tongyi\.aliyun\.com$/, 'Qwen'], [/(^|\.)you\.com$/, 'You.com'], [/(^|\.)phind\.com$/, 'Phind'], [/(^|\.)pi\.ai$/, 'Pi'],
    [/notebooklm\.google\.com$/, 'NotebookLM'], [/aistudio\.google\.com$/, 'Google AI Studio'], [/(^|\.)character\.ai$/, 'Character.AI'],
    [/(^|\.)z\.ai$|chatglm\.cn$/, 'Z.ai'], [/(^|\.)manus\.im$/, 'Manus'], [/(^|\.)genspark\.ai$/, 'Genspark'], [/(^|\.)t3\.chat$/, 'T3 Chat'],
    [/(^|\.)typingmind\.com$/, 'TypingMind'], [/(^|\.)lmarena\.ai$/, 'LMArena'], [/(^|\.)openrouter\.ai$/, 'OpenRouter'], [/(^|\.)notion\.so$/, 'Notion AI'],
    [/(^|\.)hebbia\.(ai|com)$/, 'Hebbia'], [/(^|\.)rogo\.ai$/, 'Rogo'], [/(^|\.)alpha-sense\.com$/, 'AlphaSense'], [/(^|\.)fiscal\.ai$/, 'Fiscal.ai']
  ];

  function siteName() {
    var h = location.hostname.replace(/^www\./, '');
    for (var i = 0; i < KNOWN_AI_HOSTS.length; i++) if (KNOWN_AI_HOSTS[i][0].test(h)) return KNOWN_AI_HOSTS[i][1];
    var og = document.querySelector('meta[property="og:site_name"], meta[name="application-name"]');
    if (og && og.content && og.content.length < 40) return og.content.trim();
    var base = h.replace(/^(app|chat|www)\./, '').split('.')[0];
    return base && !/^\d+$/.test(base) ? base.charAt(0).toUpperCase() + base.slice(1) : 'AI';
  }

  var USER_WORDS = /^(user|human|me|you|your|yours|mine|self|question|query|prompt|request|outgoing|sent|outbound|customer|requester|own)$/;
  var AI_WORDS = /^(assistant|bot|ai|model|answer|response|agent|incoming|received|inbound|reply|llm|copilot|claude|gpt|gemini|chatbot|system|generation|completion)$/;
  var ROLE_ATTRS = ['data-message-author-role', 'data-role', 'data-author', 'data-author-role', 'data-sender', 'data-sender-type', 'data-from',
    'data-message-role', 'data-type', 'data-message-type', 'data-testid', 'data-test-id', 'data-qa', 'data-cy', 'aria-label', 'class', 'id'];
  var MESSAGE_WORDS = /message|msg|turn|bubble|chat|entry|query|question|answer|response|reply|prompt|request|exchange|conversation|item|row|block|content|text/i;

  function words(v) {
    return String(v || '').replace(/([a-z])([A-Z])/g, '$1 $2').toLowerCase().split(/[^a-z0-9]+/).filter(Boolean);
  }

  // 'user', 'ai' or '' for one element, from its own attributes.
  function roleOf(el) {
    var u = 0, a = 0;
    // Custom tags such as <user-query> / <model-response>.
    if (el.tagName.indexOf('-') > 0) words(el.tagName).forEach(function (x) { if (USER_WORDS.test(x)) u++; else if (AI_WORDS.test(x)) a++; });
    for (var i = 0; i < ROLE_ATTRS.length; i++) {
      var name = ROLE_ATTRS[i];
      var v = el.getAttribute(name);
      if (!v) continue;
      if (name === 'class' && v.length > 400) continue;
      var w = words(v);
      // A bare class word like "ai" or "you" only counts next to a
      // message-ish word ("ai-message", "you bubble"); attributes made for
      // roles (data-role, data-author...) count on their own.
      var strong = /role|author|sender|from|type/.test(name);
      var messageish = strong || MESSAGE_WORDS.test(v) || name === 'aria-label';
      if (!messageish) continue;
      w.forEach(function (x) { if (USER_WORDS.test(x)) u++; else if (AI_WORDS.test(x)) a++; });
    }
    if (u && !a) return 'user';
    if (a && !u) return 'ai';
    return '';
  }

  function visibleText(el) {
    return (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
  }

  function isChrome(el) {
    return !!el.closest('nav, aside[role="navigation"], [role="navigation"], header[role="banner"], form, [role="dialog"]:not([aria-modal="false"]), footer, [contenteditable="true"], textarea');
  }

  function inDocOrder(list) {
    return list.sort(function (x, y) { return x.el === y.el ? 0 : (x.el.compareDocumentPosition(y.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1); });
  }

  // 1. Elements labelled as a user or AI message.
  function findLabelled(root) {
    var found = [];
    var all = root.querySelectorAll('*');
    for (var i = 0; i < all.length && i < 40000; i++) {
      var el = all[i];
      if ((!el.attributes.length && el.tagName.indexOf('-') < 0) || /^(SCRIPT|STYLE|SVG|PATH|BUTTON|INPUT|TEXTAREA|IMG|LINK|META)$/.test(el.tagName)) continue;
      var r = roleOf(el);
      if (!r) continue;
      if (isChrome(el)) continue;
      var t = visibleText(el);
      if (!t) continue;
      found.push({ el: el, role: r, len: t.length });
    }
    // Keep the outermost element per message, but never one that holds both
    // a user and an AI message (that is the whole chat, not a message).
    var keep = found.filter(function (f) {
      for (var j = 0; j < found.length; j++) {
        var g = found[j];
        if (g === f || !g.el.contains(f.el)) continue;
        if (g.role === f.role && !holdsBoth(g.el, found)) return false;
      }
      return !holdsBoth(f.el, found);
    });
    return inDocOrder(keep);
  }
  function holdsBoth(el, found) {
    var u = false, a = false;
    for (var i = 0; i < found.length; i++) {
      if (found[i].el === el || !el.contains(found[i].el)) continue;
      if (found[i].role === 'user') u = true; else a = true;
      if (u && a) return true;
    }
    return false;
  }

  // The scrolling box the chat lives in (or the page itself).
  function scrollerOf(el) {
    for (var p = el && el.parentElement; p && p !== document.body; p = p.parentElement) {
      var cs = getComputedStyle(p);
      if (/(auto|scroll|overlay)/.test(cs.overflowY) && p.scrollHeight > p.clientHeight + 40) return p;
    }
    return document.scrollingElement || document.documentElement;
  }

  // 2. No labels: the repeated blocks in the biggest scrolling text area.
  function findByLayout(root) {
    var best = null;
    var scrollers = Array.prototype.slice.call(root.querySelectorAll('*')).filter(function (el) {
      if (isChrome(el)) return false;
      var cs = getComputedStyle(el);
      return /(auto|scroll|overlay)/.test(cs.overflowY) && el.scrollHeight > el.clientHeight + 40 && el.clientHeight > 150;
    });
    scrollers.push(document.body);
    scrollers.forEach(function (sc) {
      // Walk down single-child wrappers to the element that holds the messages.
      var list = sc;
      for (var d = 0; d < 12; d++) {
        var kids = Array.prototype.filter.call(list.children, function (c) { return visibleText(c).length > 0; });
        if (kids.length === 1) list = kids[0]; else break;
      }
      var items = Array.prototype.filter.call(list.children, function (c) {
        return !isChrome(c) && visibleText(c).length > 1 && c.getBoundingClientRect().height > 8;
      });
      if (items.length < 2) return;
      var textLen = items.reduce(function (s, c) { return s + visibleText(c).length; }, 0);
      var score = Math.min(items.length, 60) * 10 + Math.min(textLen, 20000) / 100;
      if (!best || score > best.score) best = { score: score, list: list, items: items };
    });
    if (!best) return [];
    var box = best.list.getBoundingClientRect();
    return best.items.map(function (c) {
      // Find the block's visible content and see where it sits.
      var inner = c, r = c.getBoundingClientRect();
      for (var d = 0; d < 6; d++) {
        var k = Array.prototype.filter.call(inner.children, function (x) { return visibleText(x).length > 0; });
        if (k.length !== 1) break;
        inner = k[0];
      }
      r = inner.getBoundingClientRect();
      var cs = getComputedStyle(inner);
      var rightAligned = box.width > 0 && r.width < box.width * 0.85 && (r.left - box.left) > (box.right - r.right) + 24;
      var bubble = cs.backgroundColor && !/rgba\(0, 0, 0, 0\)|transparent/.test(cs.backgroundColor) && r.width < box.width * 0.9;
      var rich = !!c.querySelector('h1,h2,h3,h4,ul,ol,pre,table,blockquote');
      var role = rightAligned || (bubble && !rich) ? 'user' : 'ai';
      return { el: c, role: role, len: visibleText(c).length };
    });
  }

  function findChat(root) {
    root = root || document.body;
    var m = findLabelled(root);
    var users = m.filter(function (x) { return x.role === 'user'; }).length;
    var ais = m.length - users;
    if (users && ais) return { how: 'labels', messages: m };
    var l = findByLayout(root);
    var lu = l.filter(function (x) { return x.role === 'user'; }).length;
    if (l.length >= 2 && lu && lu < l.length) return { how: 'layout', messages: l };
    if (m.length >= 2) return { how: 'labels', messages: m };
    return { how: 'none', messages: l.length >= 2 ? l : [] };
  }

  // Open collapsed sections inside replies (thinking, steps, tool calls)
  // without pressing anything that acts: only <details> and toggles whose
  // label reads like "show / view / thought / steps".
  async function expandWork(scope, opts) {
    var n = 0;
    scope.querySelectorAll('details:not([open])').forEach(function (d) { d.open = true; n++; });
    Array.prototype.slice.call(scope.querySelectorAll('[aria-expanded="false"]')).forEach(function (b) {
      var label = ((b.getAttribute('aria-label') || '') + ' ' + visibleText(b)).slice(0, 120);
      if (!/(show|view|see|expand|thought|thinking|reason|steps?|tool|work|details|sources?|more|ran|used|called|read|searched|analy[sz]ed|calculat)/i.test(label)) return;
      if (/(delete|remove|send|submit|retry|regenerate|copy|share|edit|stop|cancel|download|upload|rename|archive|like|dislike|feedback|report|logout|sign)/i.test(label)) return;
      if (b.closest('nav, form, [role="navigation"], [role="menu"]')) return;
      try { b.click(); n++; } catch (e) { /* ignore */ }
    });
    if (n) await sleep(700, opts);
    return n;
  }

  function messageKey(m) { return m.role + '|' + visibleText(m.el).slice(0, 300); }

  async function collectAll(opts) {
    var first = findChat();
    if (!first.messages.length) return first;
    var sc = scrollerOf(first.messages[0].el);
    var start = sc.scrollTop;
    var tall = sc.scrollHeight > sc.clientHeight * 1.5;
    if (!tall) return first;
    // Load older messages: go to the top until nothing more appears.
    var lastH = -1;
    for (var i = 0; i < 25 && sc.scrollHeight !== lastH; i++) {
      lastH = sc.scrollHeight;
      sc.scrollTop = 0;
      toast('loading earlier messages...');
      await sleep(900, opts);
    }
    // Walk down and collect, since long chats may only keep what is on screen.
    var seen = {}, out = [], how = first.how, guard = 0;
    while (guard++ < 400) {
      var now = findChat();
      if (now.how !== 'none') how = now.how;
      now.messages.forEach(function (m) {
        var k = messageKey(m);
        if (seen[k]) { seen[k].el = m.el; return; }
        // Text grows while a message is half on screen; keep the longest.
        for (var j = Math.max(0, out.length - 4); j < out.length; j++) {
          var o = out[j];
          var mt = visibleText(m.el);
          var shorter = Math.min(mt.length, o.text.length);
          if (o.role === m.role && shorter >= 60 && (o.text.indexOf(mt.slice(0, 80)) === 0 || mt.indexOf(o.text.slice(0, 80)) === 0)) {
            if (visibleText(m.el).length > o.text.length) { o.el = m.el; o.text = visibleText(m.el); o.md = null; }
            seen[k] = o; return;
          }
        }
        var rec = { el: m.el, role: m.role, text: visibleText(m.el) };
        seen[k] = rec; out.push(rec);
      });
      // Turn each message into Markdown while it is still on the page.
      for (var q = 0; q < out.length; q++) if (out[q].md == null && document.contains(out[q].el)) {
        if (opts.mode === 'full' && out[q].role === 'ai') await expandWork(out[q].el, opts);
        out[q].md = htmlToMd(out[q].el, null, opts.mode === 'full');
      }
      if (sc.scrollTop + sc.clientHeight >= sc.scrollHeight - 4) break;
      sc.scrollTop += Math.max(200, sc.clientHeight * 0.8);
      toast('reading messages (' + out.length + ')...');
      await sleep(350, opts);
    }
    sc.scrollTop = start;
    return { how: how, messages: out, collected: true };
  }

  /* ------------------------------------------------------------------ *
   * Perplexity: full thread data (what perplexity.ai itself loads)
   * ------------------------------------------------------------------ */
  function ppxStep(st) {
    var type = String(st.step_type || 'STEP');
    var key = Object.keys(st).filter(function (k) { return /_content$/.test(k) && st[k]; })[0];
    var c = key ? st[key] : {};
    if (type === 'INITIAL_QUERY') return null;
    var label = type.toLowerCase().replace(/_/g, ' ');
    if (c && Array.isArray(c.queries) && c.queries.length) {
      return { label: label, input: c.queries.map(function (q) { return '- ' + (typeof q === 'string' ? q : (q.query || JSON.stringify(q))); }).join('\n') };
    }
    if (c && Array.isArray(c.urls) && c.urls.length) return { label: label, input: c.urls.map(function (u) { return '- ' + u; }).join('\n') };
    if (c && Array.isArray(c.web_results) && c.web_results.length) {
      return { label: label, input: c.web_results.map(function (w) { return '- ' + (w.name || w.url) + (w.url ? ' (' + w.url + ')' : ''); }).join('\n') };
    }
    if (c && typeof c.goal_id !== 'undefined' && c.description) return { label: label, input: c.description };
    return { label: label, input: c && Object.keys(c).length ? '```json\n' + JSON.stringify(c, null, 2) + '\n```' : '' };
  }

  async function exportPerplexityData(opts) {
    var m = location.pathname.match(/\/search\/([^/?#]+)/);
    if (!m) throw new Error('open a Perplexity thread first');
    toast('loading the full thread data...');
    var entries = [], cursor = null, guard = 0;
    do {
      var url = '/rest/thread/' + encodeURIComponent(m[1]) + '?with_parent_info=true&with_schematized_response=true&version=2.18&source=default&limit=100' + (cursor ? '&cursor=' + encodeURIComponent(cursor) : '');
      var r = await fetch(url, { credentials: 'include' });
      if (!r.ok) throw new Error('thread data unavailable (' + r.status + ')');
      var j = await r.json();
      (j.entries || []).forEach(function (e) { if (!entries.some(function (x) { return x.uuid === e.uuid; })) entries.push(e); });
      cursor = j.has_next_page ? j.next_cursor : null;
    } while (cursor && guard++ < 20);
    if (!entries.length) throw new Error('no messages in the thread data');
    entries.sort(function (a, b) { return String(a.entry_created_datetime || '').localeCompare(String(b.entry_created_datetime || '')); });

    var full = opts.mode === 'full';
    var max = opts.maxToolChars || 0;
    var allSources = SourceList();
    var stats = { messages: 0, toolCalls: 0, thinking: 0, sources: 0 };
    var out = [];
    var model = '';

    entries.forEach(function (e, idx) {
      var turnNo = idx + 1;
      var when = e.entry_created_datetime ? ', ' + fmtDate(e.entry_created_datetime) : '';
      var blocks = e.blocks || [];
      function block(u) { return blocks.filter(function (b) { return b.intended_usage === u; })[0]; }
      if (e.display_model) model = e.display_model;

      // You
      stats.messages++;
      var ub = [];
      var att = (e.attachments || []).map(function (a) { return typeof a === 'string' ? a : (a && (a.url || a.file_url)); }).filter(Boolean);
      if (att.length) ub.push('**Attached:** ' + att.map(function (u) { return '[' + decodeURIComponent(u.split('?')[0].split('/').pop()).replace(/[\[\]]/g, '') + '](' + u + ')'; }).join(', '));
      if (e.query_str) ub.push(String(e.query_str).trim());
      out.push('## You (turn ' + turnNo + when + ')\n\n' + (ub.join('\n\n') || '_(no text)_'));

      // Perplexity
      stats.messages++;
      var body = [];
      var srcs = SourceList();
      var web = [];
      blocks.forEach(function (b) {
        var wr = b.web_result_block && b.web_result_block.web_results;
        if (wr) wr.forEach(function (w) { web.push(w); if (w.url) srcs.add(w.url, w.name); });
      });

      if (full) {
        var stepNo = 0;
        blocks.forEach(function (b) {
          var pb = b.plan_block;
          if (pb) {
            (pb.steps || []).forEach(function (st) {
              var s = ppxStep(st);
              if (!s) return;
              stepNo++; stats.toolCalls++;
              body.push('**[Step ' + stepNo + ': ' + s.label + ']**' + (s.input ? '\n\n' + trim(s.input, max) : ''));
            });
            var goals = (pb.goals || []).map(function (g) { return g && g.description; }).filter(function (d) { return d && d.length < 300; });
            if (goals.length && b.intended_usage === 'plan') body.push('**[Plan]**\n\n' + goals.map(function (g) { return '- ' + g; }).join('\n'));
          }
          if (/reason|think/i.test(b.intended_usage || '') && b.markdown_block && b.markdown_block.answer) {
            stats.thinking++;
            body.push('**[Thinking]**\n\n' + quote(trim(b.markdown_block.answer, max)));
          }
        });
      }

      // The answer: "ask_text" holds it whole; older threads keep it in "text".
      var ans = block('ask_text') && block('ask_text').markdown_block && block('ask_text').markdown_block.answer;
      if (!ans) ans = blocks.filter(function (b) { return /^ask_text_\d+_markdown$/.test(b.intended_usage || '') && b.markdown_block; })
        .map(function (b) { return b.markdown_block.answer || ''; }).join('');
      if (!ans && typeof e.text === 'string') {
        try { var steps = JSON.parse(e.text); var fin = (steps || []).filter(function (s) { return s.step_type === 'FINAL'; })[0]; ans = fin && JSON.parse(fin.content.answer).answer; } catch (x) { ans = ''; }
      }
      // [1][2] markers -> links to the numbered web results.
      ans = String(ans || '').replace(/\[(\d{1,3})\](?!\()/g, function (all, n) {
        var w = web[+n - 1];
        return w && w.url ? '[[' + n + ']](' + w.url + ')' : all;
      });
      if (ans.trim()) body.push(ans.trim());

      if (opts.includeSources && srcs.items().length) body.push('**Sources used in this reply:**\n\n' + srcs.md());
      srcs.items().forEach(function (x) { allSources.add(x.url, x.title); });
      out.push('## Perplexity (turn ' + turnNo + when + ')\n\n' + (body.join('\n\n') || '_(no text)_'));
    });

    stats.sources = allSources.items().length;
    return { site: 'Perplexity', title: entries[0].thread_title || entries[0].query_str || document.title, model: model, body: out.join('\n\n---\n\n'), sources: allSources, stats: stats };
  }

  /* ------------------------------------------------------------------ *
   * DeepSeek: full conversation data (what chat.deepseek.com itself loads)
   * Written from DeepSeek's known format; not yet seen on a real account,
   * so anything unexpected falls back to the general page reader.
   * ------------------------------------------------------------------ */
  async function exportDeepSeekData(opts) {
    var m = location.pathname.match(/\/s\/([0-9a-f-]{16,})/i) || location.pathname.match(/\/chat\/([0-9a-f-]{16,})/i);
    if (!m) throw new Error('open a DeepSeek chat first');
    var token = '';
    try { var raw = localStorage.getItem('userToken'); var tk = raw && JSON.parse(raw); token = (tk && (tk.value || tk)) || ''; } catch (e) { token = ''; }
    if (!token || typeof token !== 'string') throw new Error('not signed in');
    toast('loading the full conversation data...');
    var r = await fetch('/api/v0/chat/history_messages?chat_session_id=' + encodeURIComponent(m[1]), {
      credentials: 'include', headers: { Authorization: 'Bearer ' + token, 'x-client-platform': 'web' }
    });
    if (!r.ok) throw new Error('conversation data unavailable (' + r.status + ')');
    var j = await r.json();
    var biz = j && j.data && (j.data.biz_data || j.data);
    var msgs = (biz && biz.chat_messages) || [];
    if (!msgs.length) throw new Error('no messages in the conversation data');
    var session = (biz && biz.chat_session) || {};

    // The branch on screen: from the current message up through parents.
    var byId = {};
    msgs.forEach(function (x) { byId[x.message_id] = x; });
    var chain = [];
    var cur = byId[session.current_message_id] || msgs[msgs.length - 1], guard = 0;
    while (cur && guard++ < 10000) { chain.unshift(cur); cur = cur.parent_id != null ? byId[cur.parent_id] : null; }

    var full = opts.mode === 'full';
    var max = opts.maxToolChars || 0;
    var allSources = SourceList();
    var stats = { messages: 0, toolCalls: 0, thinking: 0, sources: 0 };
    var out = [];
    var turn = 0;

    chain.forEach(function (msg) {
      var isUser = /user/i.test(msg.role || '');
      if (isUser) turn++;
      stats.messages++;
      var body = [];
      var srcs = SourceList();
      var results = [];
      var think = msg.thinking_content || '';
      var text = msg.content || '';
      // Newer format: fragments of THINK / SEARCH / RESPONSE / REQUEST.
      (msg.fragments || []).forEach(function (f) {
        var t = String(f.type || '').toUpperCase();
        if (t === 'THINK') think += (think ? '\n\n' : '') + (f.content || '');
        else if (t === 'SEARCH') {
          (f.results || []).forEach(function (x) { results.push(x); });
          if (full && (f.queries || []).length) { stats.toolCalls++; body.push('**[Step: web search]**\n\n' + f.queries.map(function (q) { return '- ' + (q.query || q); }).join('\n')); }
        } else if (t === 'RESPONSE' || t === 'REQUEST') text += (text ? '\n\n' : '') + (f.content || '');
      });
      (msg.search_results || []).forEach(function (x) { results.push(x); });
      results.forEach(function (x) { if (x && x.url) srcs.add(x.url, x.title); });
      if (full && think.trim()) { stats.thinking++; body.push('**[Thinking]**\n\n' + quote(trim(think.trim(), max))); }
      // [citation:3] -> link to that search result.
      text = String(text).replace(/\[citation:(\d+)\]/g, function (all, n) {
        var hit = results.filter(function (x) { return +x.cite_index === +n; })[0] || results[+n - 1];
        return hit && hit.url ? ' [[' + n + ']](' + hit.url + ')' : '';
      }).replace(/[ \t]+\[\[/g, ' [[');
      var files = (msg.files || []).map(function (f) { return f && (f.file_name || f.name); }).filter(Boolean);
      if (files.length) body.unshift('**Attached:** ' + files.map(function (n) { return '`' + n + '`'; }).join(', '));
      if (text.trim()) body.push(text.trim());
      if (opts.includeSources && !isUser && srcs.items().length) body.push('**Sources used in this reply:**\n\n' + srcs.md());
      srcs.items().forEach(function (x) { allSources.add(x.url, x.title); });
      var when = msg.inserted_at ? ', ' + fmtDate(new Date((msg.inserted_at > 1e12 ? msg.inserted_at : msg.inserted_at * 1000)).toISOString()) : '';
      out.push('## ' + (isUser ? 'You' : 'DeepSeek') + ' (turn ' + turn + when + ')\n\n' + (body.join('\n\n') || '_(no text)_'));
    });

    stats.sources = allSources.items().length;
    return { site: 'DeepSeek', title: session.title || document.title, model: '', body: out.join('\n\n---\n\n'), sources: allSources, stats: stats };
  }

  async function exportGeneric(opts) {
    var full = opts.mode === 'full';
    var name = opts.siteName || siteName();
    toast('looking for the conversation...');
    var chat = await collectAll(opts);
    var hasUser = chat.messages.some(function (m) { return m.role === 'user'; });
    var hasAi = chat.messages.some(function (m) { return m.role !== 'user'; });
    if (!chat.messages.length || !hasUser || !hasAi) throw new Error('Could not find a conversation on this page. Open the chat itself (not the chat list) and try again, or use "Convert this page".');
    var allSources = SourceList();
    var out = [], turn = 0;
    var bag = FileBag(), picNo = 0;
    for (var i = 0; i < chat.messages.length; i++) {
      var m = chat.messages[i];
      var md = m.md;
      if (md == null) {
        if (full && m.role === 'ai') await expandWork(m.el, opts);
        md = htmlToMd(m.el, null, full);
      }
      md = (md || '').trim();
      // Pictures and file links inside the message (what the AI made, or what you attached).
      var found = [];
      if (m.el && document.contains(m.el)) {
        var who = m.role === 'user' ? 'you' : 'ai';
        genericFiles(m.el).forEach(function (x) {
          var f = bag.get(x.url) || bag.add({ name: x.name || ((who === 'you' ? 'attached image ' : 'image ') + (++picNo) + '.png'), by: who, url: x.url, origHref: x.url }, x.url);
          if (found.indexOf(f) < 0) found.push(f);
          if (x.url && md.indexOf(x.url) >= 0) md = md.split(x.url).join(bag.pathTok(f));
        });
      }
      if (!md && !found.length) continue;
      if (m.role === 'user') {
        turn++;
        out.push('## You (turn ' + turn + ')\n\n' + (found.length ? '**Attached:** ' + found.map(bag.tok).join(', ') + '\n\n' : '') + md);
      } else {
        if (m.el && document.contains(m.el)) allLinks(m.el).forEach(function (a) { if (!isChromeLink(a)) allSources.add(a.href, textOf(a)); });
        out.push('## ' + name + (turn ? ' (turn ' + turn + ')' : '') + '\n\n' + md + (found.length ? '\n\n**Files it made:** ' + found.map(bag.tok).join(', ') : ''));
      }
    }
    var title = document.title;
    var h = document.querySelector('[aria-current="page"], [data-active="true"], .active');
    if (/^\s*(new chat|chat|home)?\s*$/i.test(cleanTitle(title).replace(name, '')) && h && visibleText(h).length < 90) title = visibleText(h);
    return {
      site: name, generic: true, title: betterTitle(title, name, chat.messages), body: out.join('\n\n---\n\n'), sources: allSources,
      stats: { turns: turn, messages: out.length }, files: bag.list,
      note: chat.how === 'layout' ? 'This app does not label who said what, so speakers were worked out from the layout. Worth a quick check.' : ''
    };
  }

  // Files inside one message of any AI app: real pictures (not icons or
  // avatars) and links that point at a downloadable file.
  var FILE_LINK = /\.(pdf|docx?|xlsx?|xlsm|pptx?|csv|tsv|zip|txt|md|json|xml|html?|png|jpe?g|gif|webp|svg|mp3|wav|mp4|py|js|ts|ipynb|sql|r)(\?|#|$)/i;
  function genericFiles(el) {
    var out = [];
    function add(url, name) {
      if (!url || /^(javascript:|mailto:|#)/i.test(url) || out.some(function (x) { return x.url === url; })) return;
      out.push({ url: url, name: name || '' });
    }
    Array.prototype.forEach.call(el.querySelectorAll('img'), function (im) {
      var src = im.currentSrc || im.src;
      if (!src || /^data:image\/svg/i.test(src) || /avatar|icon|logo|favicon|emoji/i.test((im.className || '') + ' ' + (im.alt || '') + ' ' + src)) return;
      var w = im.naturalWidth || im.width, h = im.naturalHeight || im.height;
      if (w && h && (w < 120 || h < 80)) return;
      if (im.closest('a[href^="http"]') && !FILE_LINK.test(im.closest('a').href)) return;   // a link preview card, not a file
      var nm = (src.split('?')[0].split('/').pop() || '');
      add(src, /\.(png|jpe?g|gif|webp)$/i.test(nm) ? decodeURIComponent(nm) : '');
    });
    Array.prototype.forEach.call(el.querySelectorAll('a[href]'), function (a) {
      var href = a.href;
      var dl = a.getAttribute('download');
      if (dl === null && !/^blob:/i.test(href) && !(FILE_LINK.test(href) && (new URL(href, location.href).origin === location.origin || /files?|download|attachment|storage|blob|cdn|assets|uploads?/i.test(href)))) return;
      var nm = (dl && dl.trim()) || decodeURIComponent(href.split('?')[0].split('#')[0].split('/').pop() || '') || textOf(a);
      add(href, FILE_LINK.test(nm) ? nm : (textOf(a) && FILE_LINK.test(textOf(a)) ? textOf(a) : nm));
    });
    return out;
  }

  // A useful file name: the chat's title, unless the page title is empty,
  // just the app's name, or an id (then the start of the first question).
  function betterTitle(title, name, messages) {
    var t = cleanTitle(title || '');
    var bare = t.toLowerCase().replace(/[^a-z0-9]/g, '');
    var isName = !bare || bare === name.toLowerCase().replace(/[^a-z0-9]/g, '') || /^(new chat|chat|home|untitled|ai chat|conversation|assistant|agent)$/i.test(t);
    var isId = !/\s/.test(t) && /\d/.test(t) && t.length >= 8;
    if (!isName && !isId) return t;
    var first = (messages || []).filter(function (m) { return m.role === 'user'; })[0];
    var q = first ? (first.text || visibleText(first.el || document.createElement('i'))) : '';
    q = q.replace(/\s+/g, ' ').trim().split(' ').slice(0, 9).join(' ').replace(/[.,;:!?]+$/, '');
    return q ? q + (q.length < (first.text || '').length ? '...' : '') : (t || name + ' chat');
  }

  // Quick check, used by the popup on every frame: is there a chat here?
  window.__ptmAiProbe = function () {
    var known = detectSite();
    if (known && !arguments[0]) return { known: known, score: 100, site: known };
    var chat = findChat();
    var users = chat.messages.filter(function (m) { return m.role === 'user'; }).length;
    var ais = chat.messages.length - users;
    var named = KNOWN_AI_HOSTS.some(function (k) { return k[0].test(location.hostname.replace(/^www\./, '')); });
    // A box to type the next message in is a strong sign of a chat app.
    var composer = Array.prototype.some.call(document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"], input[type="text"]'), function (el) {
      var hint = (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-placeholder') || '');
      return /ask|message|chat|prompt|reply|type|anything|question|follow/i.test(hint);
    });
    var score = (users && ais ? 40 : 0) + Math.min(chat.messages.length, 20) * 2 + (chat.how === 'labels' ? 20 : 0) + (named ? 30 : 0) + (composer ? 20 : 0);
    var textLen = chat.messages.reduce(function (s, m) { return s + m.len; }, 0);
    if (textLen < 40) score = named ? 20 : 0;
    return { known: '', score: score, site: siteName(), how: chat.how, messages: chat.messages.length, named: named, composer: composer };
  };

  /* ------------------------------------------------------------------ *
   * Entry point
   * ------------------------------------------------------------------ */
  function detectSite() {
    var h = location.hostname;
    if (/(^|\.)claude\.ai$/.test(h)) return 'claude';
    if (/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/.test(h)) return 'chatgpt';
    if (/^gemini\.google\.com$/.test(h)) return 'gemini';
    if (/(^|\.)grok\.com$/.test(h) || (/(^|\.)x\.com$/.test(h) && /\/i\/grok/.test(location.pathname))) return 'grok';
    if (/(^|\.)perplexity\.ai$/.test(h)) return 'perplexity';
    if (/^chat\.deepseek\.com$/.test(h)) return 'deepseek';
    return '';
  }

  function buildDocument(res, opts) {
    var full = opts.mode === 'full';
    var meta = [
      '# ' + cleanTitle(res.title),
      '',
      '- **Source:** ' + res.site + ' (' + location.href + ')',
      res.model ? '- **Model:** ' + res.model : '',
      '- **Exported:** ' + fmtDate(new Date().toISOString()),
      '- **Export type:** ' + (full
        ? 'Full: messages plus thinking, every tool call (inputs) and tool result, in the order they happened'
        : 'Chat only: messages and replies'),
      res.filesNote ? '- **Files:** ' + res.filesNote : '',
      opts.maxToolChars ? '- **Note:** long tool inputs/results trimmed to ' + opts.maxToolChars.toLocaleString() + ' characters each' : ''
    ].filter(Boolean).join('\n');
    var legend = full && res.generic
      ? '\n\n> **How to read this file:** each `## You` / `## ' + res.site + '` section is one message. ' +
        '**[Step: ...]** marks a step the AI showed (a file it read, a calculation it ran); the text under it is what that step showed.'
      : full
      ? '\n\n> **How to read this file:** each `## You` / `## ' + res.site.split(' ')[0] + '` section is one message. ' +
        'Inside replies, **[Thinking]** is the AI\'s reasoning, **[Step N: tool ...]** shows exactly what the AI ran and with what input, ' +
        'and **[Result of ...]** shows what came back. Plain text is what the AI said to the user.'
      : '';
    var srcs = opts.includeSources && res.sources && res.sources.items().length
      ? '\n\n---\n\n## All sources (' + res.sources.items().length + ')\n\n' + res.sources.md()
      : '';
    var fm = '';
    if (opts.frontMatter) {
      var q = function (v) { return '"' + String(v == null ? '' : v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ') + '"'; };
      fm = ['---', 'title: ' + q(cleanTitle(res.title)), 'source: ' + q(location.href), 'site: ' + q(res.site.split(' ')[0]),
        res.model ? 'model: ' + q(res.model) : '', 'exported: ' + q(new Date().toISOString()),
        'type: ' + q(full ? 'ai-chat-full' : 'ai-chat'), 'tags: [ai-chat]', '---'].filter(Boolean).join('\n') + '\n\n';
    }
    return fm + meta + legend + '\n\n---\n\n' + res.body + srcs + '\n';
  }

  function cleanTitle(t) {
    // Drop only an app-name suffix ("My chat - Claude", "Report | Perplexity"),
    // never real words after a dash in the chat's own title.
    var names = ['Claude', 'Google Gemini', 'Gemini', 'Grok', 'ChatGPT'].concat(KNOWN_AI_HOSTS.map(function (k) { return k[1]; }));
    try { names.push(siteName()); } catch (e) { /* ignore */ }
    var out = String(t || 'AI chat').replace(/^\(\d+\)\s*/, '').trim();
    for (var i = 0; i < names.length; i++) {
      var n = names[i].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      out = out.replace(new RegExp('\\s+[-|·–]\\s+' + n + '$', 'i'), '');
    }
    return out.trim() || 'AI chat';
  }

  function makeFilename(template, res, opts) {
    var site = res.site.split(' ')[0];
    var name = (template || '{title} - {site} ({mode})').replace(/\{(\w+)\}/g, function (m, k) {
      if (k === 'title') return cleanTitle(res.title);
      if (k === 'site') return site;
      if (k === 'mode') return opts.mode === 'full' ? 'full' : 'chat';
      if (k === 'date') { var d = new Date(); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
      return m;
    });
    name = name.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').replace(/\(\s*\)/g, '').trim().slice(0, 120);
    return (name || 'AI chat') + '.md';
  }

  /* ------------------------------------------------------------------ *
   * Files the chat made: fetch them, give them names, link them
   * ------------------------------------------------------------------ */
  function safeName(n) {
    var s = String(n || 'file').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim();
    if (s.length > 100) { var m = s.match(/(\.[A-Za-z0-9]{1,6})$/); s = s.slice(0, 100 - (m ? m[1].length : 0)).trim() + (m ? m[1] : ''); }
    return s.replace(/^\.+/, '') || 'file';
  }
  // Code and config files: left out unless "Include code files" is ticked.
  var CODE_EXT = /\.(js|mjs|cjs|jsx|ts|tsx|py|pyw|ipynb|css|scss|sass|less|sh|bash|zsh|command|ps1|bat|cmd|swift|java|kt|kts|go|rs|rb|php|c|h|cc|cpp|hpp|cs|m|mm|r|sql|lua|pl|vue|svelte|bas|vba|gradle|json|jsonc|yml|yaml|toml|ini|cfg|conf|env|plist|lock)$/i;
  function isCodeFile(name) { return CODE_EXT.test(String(name || '').trim()); }

  function linkPath(p) {
    return p.split('/').map(function (s) { return encodeURIComponent(s).replace(/\(/g, '%28').replace(/\)/g, '%29'); }).join('/');
  }

  // Same file name more than once (a file Claude kept updating): the last one
  // keeps the plain name, earlier ones become "name (v1).ext", "name (v2).ext".
  function assignPaths(list) {
    var groups = {};
    list.forEach(function (f) {
      var folder = f.by === 'you' ? 'uploads/' : 'files/';
      var key = (folder + safeName(f.name)).toLowerCase();
      (groups[key] = groups[key] || []).push(f);
      f.path = folder + safeName(f.name);
    });
    Object.keys(groups).forEach(function (k) {
      var g = groups[k];
      if (g.length < 2) return;
      g.forEach(function (f, i) {
        if (i === g.length - 1) return;
        f.path = f.path.replace(/(\.[A-Za-z0-9]{1,6})?$/, function (ext) { return ' (v' + (i + 1) + ')' + (ext || ''); });
      });
    });
  }

  // Files on another site that blocks downloads from the page (Google's image
  // server for Gemini, for example): the extension downloads them instead.
  async function viaExtension(url) {
    try {
      if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) return null;
      var res = await chrome.runtime.sendMessage({ type: 'ptm-fetch', url: url });
      if (!res || !res.ok || typeof res.b64 !== 'string') return null;
      var bin = atob(res.b64), bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return bytes;
    } catch (e) { return null; }
  }

  async function fetchOne(f) {
    try {
      var r = await fetch(f.url, { credentials: 'include', headers: f.headers || {} });
      if (r.ok && f.indirect) {
        // ChatGPT answers with JSON pointing at the real file.
        var info = await r.json().catch(function () { return {}; });
        if (info && info.download_url && (!info.status || info.status === 'success')) {
          if (info.file_name && (f.nameFromServer || !/\.[A-Za-z0-9]{1,6}$/.test(f.name))) f.name = info.file_name;
          r = await fetch(info.download_url, { credentials: 'include' });
        } else r = { ok: false };
      }
      if (r.ok) return new Uint8Array(await r.arrayBuffer());
    } catch (e) { /* try the other ways below */ }
    var other = false;
    try { other = new URL(f.url, location.href).origin !== location.origin; } catch (e) { /* ignore */ }
    if (other && !f.indirect) { var b = await viaExtension(new URL(f.url, location.href).href); if (b) return b; }
    if (f.altUrl) {
      try { var a = await fetch(f.altUrl); if (a.ok) return new Uint8Array(await a.arrayBuffer()); } catch (e) { /* gone */ }
    }
    return null;
  }

  async function fetchFiles(list) {
    var done = 0;
    var queue = list.slice();
    async function worker() {
      while (queue.length) {
        var f = queue.shift();
        if (typeof f.text === 'string') f.data = f.text;
        else {
          var data = await fetchOne(f);
          if (data) f.data = data; else f.missing = true;
        }
        done++;
        toast('saving files: ' + done + ' of ' + list.length + '...');
      }
    }
    await Promise.all([worker(), worker(), worker()]);
  }

  // Turn the file tokens in the Markdown into links (saved), "(no longer
  // available)" notes, or plain names (when files are not being saved).
  function fillFileTokens(text, list) {
    text = text.replace(/\u0000P(\d+)\u0000/g, function (m, i) {
      var f = list[+i];
      if (!f) return '#';
      return f.include && !f.missing && f.data != null ? linkPath(f.path) : (f.origHref || '#');
    });
    return text.replace(/\u0000F(\d+)\u0000/g, function (m, i) {
      var f = list[+i];
      if (!f) return '';
      var label = '`' + safeName(f.name) + '`';
      if (!f.include) return label;
      if (f.missing || f.data == null) return label + ' (no longer available)';
      return '[' + f.path.split('/').pop().replace(/[\[\]]/g, '') + '](' + linkPath(f.path) + ')';
    });
  }

  function downloadBlob(name, blob) {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 120000);
  }

  function downloadText(name, text) {
    var blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = name;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 60000);
  }

  // Reports ChatGPT draws in a sandboxed frame from another OpenAI domain (Deep
  // Research): the popup reads them frame by frame and passes them in.
  window.__ptmFrameMd = function () {
    try {
      if (window.top === window) return null;
      if (!/(^|\.)web-sandbox\.oaiusercontent\.com$/.test(location.hostname)) return null;
      var txt = ((document.body && document.body.innerText) || '').trim();
      if (txt.length < 400) return null;
      var h = document.querySelector('h1, h2');
      return { title: (h && textOf(h)) || document.title || 'Report', md: htmlToMd(document.body).trim() };
    } catch (e) { return null; }
  };

  window.__ptmAiExport = async function (options) {
    var opts = Object.assign({ mode: 'full', includeSources: true, maxToolChars: 0, download: true }, options || {});
    var site = (opts.forceGeneric ? '' : detectSite()) || 'generic';
    try {
      toast('starting...');
      var res;
      if (site === 'claude') {
        try { res = await exportClaude(opts); }
        catch (e) {
          toast('full data unavailable, reading the page instead...');
          res = await exportClaudeFromPage(opts);
          res.warning = e.message;
        }
      } else if (site === 'chatgpt') res = await exportChatGPT(opts);
      else if (site === 'gemini') res = await exportGemini(opts);
      else if (site === 'grok') res = await exportGrok(opts);
      else if (site === 'perplexity' || site === 'deepseek') {
        // Their own data first; anything unexpected falls back to the general reader.
        try { res = await (site === 'perplexity' ? exportPerplexityData(opts) : exportDeepSeekData(opts)); }
        catch (e) {
          toast('full data unavailable, reading the page instead...');
          res = await exportGeneric(opts);
          res.warning = e.message;
        }
      }
      else res = await exportGeneric(opts);

      var tpl = opts.filenameTemplate && opts.filenameTemplate !== '{title}' ? opts.filenameTemplate : '{title} - {site} ({mode})';
      var filename = makeFilename(tpl, res, opts);

      // Reports from embedded panels (read by the popup in their own frames).
      (opts.embedded || []).forEach(function (r) {
        if (!r || !r.md) return;
        var f = { name: safeName(r.title || 'Report') + '.md', by: 'ai', text: '# ' + (r.title || 'Report') + '\n\n' + r.md };
        res.files = res.files || [];
        res.files.push(f);
        res.body += '\n\n---\n\n## ' + (r.title || 'Report') + ' (report shown in a panel)\n\n' +
          '**File:** \u0000F' + (res.files.length - 1) + '\u0000\n\n' + r.md;
      });

      // Files: saved into a .zip next to the Markdown when asked for (only
      // when the page saves the file itself; copying can't carry files).
      var list = res.files || [];
      var zipping = false;
      if (list.length) {
        var skippedCode = 0;
        list.forEach(function (f) {
          var mineOk = f.by !== 'you' || opts.withUploads;
          var code = isCodeFile(f.name);
          f.include = !!(opts.withFiles && opts.download && mineOk && (!code || opts.withCode));
          if (opts.withFiles && opts.download && mineOk && code && !opts.withCode) skippedCode++;
        });
        var wanted = list.filter(function (f) { return f.include; });
        if (wanted.length) {
          await fetchFiles(wanted);   // first: some sites only tell the real file name on download
          assignPaths(wanted);
          zipping = wanted.some(function (f) { return !f.missing; });
          var made = wanted.filter(function (f) { return f.by !== 'you'; });
          res.stats = Object.assign({}, res.stats, {
            files: wanted.filter(function (f) { return !f.missing; }).length,
            filesMissing: wanted.filter(function (f) { return f.missing; }).length
          });
          res.filesNote = made.length + ' file' + (made.length === 1 ? '' : 's') + ' it made' +
            (wanted.length > made.length ? ' and ' + (wanted.length - made.length) + ' you uploaded' : '') +
            ', saved next to this file in ' + (wanted.length > made.length ? '`files/` and `uploads/`' : '`files/`') +
            (res.stats.filesMissing ? ' (' + res.stats.filesMissing + ' no longer available)' : '') +
            (skippedCode ? '; ' + skippedCode + ' code file' + (skippedCode === 1 ? '' : 's') + ' left out' : '');
        } else if (skippedCode) {
          res.filesNote = 'only code files in this chat (' + skippedCode + '), left out because "Include code files" is off';
        }
        if (skippedCode) res.stats = Object.assign({}, res.stats, { codeSkipped: skippedCode });
        res.body = fillFileTokens(res.body, list);
      }

      var doc = buildDocument(res, opts);
      if (opts.download && zipping) {
        if (!window.__ptmZip) throw new Error('the zip helper did not load; reload the extension');
        toast('building the zip...');
        var entries = [{ name: filename, data: doc, date: new Date() }];
        list.forEach(function (f) {
          if (f.include && !f.missing && f.data != null) entries.push({ name: f.path, data: f.data, date: f.date ? new Date(f.date) : new Date() });
        });
        var zipBlob = await window.__ptmZip(entries);
        filename = filename.replace(/\.md$/, '') + '.zip';
        downloadBlob(filename, zipBlob);
      } else if (opts.download) downloadText(filename, doc);
      var noFiles = opts.withFiles && opts.download && !list.some(function (f) { return f.by !== 'you' || opts.withUploads; });
      toastDone(opts.download ? 'saved "' + filename + '"' : 'done');
      return {
        ok: true, site: res.site, filename: filename, chars: doc.length, stats: res.stats, warning: res.warning || '',
        note: [res.note || '', noFiles ? (res.files ? 'No files in this chat, so it saved just the .md.' : 'No files found in this chat, so it saved just the .md.') : ''].filter(Boolean).join('\n'),
        markdown: opts.download ? '' : doc
      };
    } catch (e) {
      toastDone('failed: ' + e.message);
      return { ok: false, error: e.message };
    }
  };
})();
