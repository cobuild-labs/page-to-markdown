/* Service worker: context menus, keyboard shortcuts, first-run welcome page.
 * The long multi-page workflow lives in runner.html (a normal tab), which
 * avoids MV3 service-worker lifetime limits.
 */
/* global chrome, importScripts, PTM_CONFIG, ptmGetSettings, ptmFilename, ptmFrontMatter, ptmCountExport, pageToMarkdownExtract, ptmAiSiteFor */
importScripts('config.js', 'common.js', 'extract.js');

var AI_PATTERNS = [
  'https://claude.ai/*', 'https://*.claude.ai/*',
  'https://chatgpt.com/*', 'https://chat.openai.com/*',
  'https://gemini.google.com/*', 'https://grok.com/*', 'https://x.com/i/grok*'
];

chrome.runtime.onInstalled.addListener(function (details) {
  chrome.contextMenus.removeAll(function () {
    chrome.contextMenus.create({ id: 'ptm-page', title: 'Convert page to Markdown', contexts: ['page'] });
    chrome.contextMenus.create({ id: 'ptm-selection', title: 'Convert selection to Markdown', contexts: ['selection'] });
    // Shown on every page: the general reader handles AI apps beyond the big four.
    chrome.contextMenus.create({ id: 'ptm-ai', title: 'Export this AI chat to Markdown', contexts: ['page'] });
  });
  if (details.reason === 'install') {
    chrome.tabs.create({ url: chrome.runtime.getURL('welcome.html') });
  }
});

function flash(tabId, ok) {
  try {
    chrome.action.setBadgeBackgroundColor({ color: ok ? '#16a34a' : '#dc2626', tabId: tabId });
    chrome.action.setBadgeText({ text: ok ? '✓' : '!', tabId: tabId });
    setTimeout(function () { chrome.action.setBadgeText({ text: '', tabId: tabId }); }, 3500);
  } catch (e) { /* ignore */ }
}

function exec(details) {
  return new Promise(function (resolve, reject) {
    chrome.scripting.executeScript(details, function (results) {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(results && results[0] ? results[0].result : undefined);
    });
  });
}

// The worker has no page, so the download link is clicked inside the tab
// (see ptmDownload in common.js for why a link and not chrome.downloads).
function downloadText(filename, text, saveAs, tabId) {
  if (saveAs || !tabId) return ptmSaveText(filename, text, saveAs);
  return exec({
    target: { tabId: tabId },
    func: function (name, body) {
      var a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([body], { type: 'text/markdown;charset=utf-8' }));
      a.download = name;
      a.style.display = 'none';
      document.documentElement.appendChild(a);
      a.click();
      setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 60000);
      return true;
    },
    args: [filename, text]
  }).catch(function () { return ptmSaveText(filename, text, saveAs); });
}


async function convertTab(tab, selectionOnly) {
  var s = await ptmGetSettings();
  var result = await exec({ target: { tabId: tab.id }, func: pageToMarkdownExtract, args: [{ selectionOnly: !!selectionOnly, usePresets: s.usePresets, clean: s.cleanMode }] });
  if (!result || !result.markdown) throw new Error('Nothing to convert');
  var title = (result.title || result.url) + (result.layout === 'selection' ? ' (selection)' : '');
  var text = (s.frontMatter ? ptmFrontMatter({ title: title, url: result.url, type: result.layout === 'selection' ? 'selection' : 'page' }) : '') +
    (s.sourceHeader ? '# ' + title + '\n\nSource: ' + result.url + '\n\n---\n\n' : '') + result.markdown + '\n';
  await downloadText(ptmFilename(s.filenameTemplate, { title: title, site: new URL(result.url).hostname }), text, s.saveAs, tab.id);
  await ptmCountExport();
}

async function aiExportTab(tab) {
  var s = await ptmGetSettings();
  var known = ptmAiSiteFor(tab.url || '');
  await exec({ target: { tabId: tab.id }, files: ['zip.js', 'aiexport.js'] });
  var res = await exec({
    target: { tabId: tab.id },
    func: function (o) { return window.__ptmAiExport(o); },
    args: [{ mode: s.aiMode, includeSources: s.aiSources, maxToolChars: s.aiTrim, frontMatter: s.frontMatter, filenameTemplate: s.filenameTemplate, download: true, siteName: known ? known.name : '', withFiles: s.aiFiles, withUploads: s.aiUploads, withCode: s.aiCode }]
  });
  if (!res || !res.ok) throw new Error((res && res.error) || 'Export failed');
  await ptmCountExport();
}

function isAiUrl(url) {
  return !!ptmAiSiteFor(url || '');
}

function run(tab, job) {
  if (!tab || !tab.id) return;
  job().then(function () { flash(tab.id, true); }).catch(function (e) {
    console.warn('Page to Markdown:', e && e.message);
    flash(tab.id, false);
  });
}


chrome.contextMenus.onClicked.addListener(function (info, tab) {
  if (info.menuItemId === 'ptm-page') run(tab, function () { return convertTab(tab, false); });
  else if (info.menuItemId === 'ptm-selection') run(tab, function () { return convertTab(tab, true); });
  else if (info.menuItemId === 'ptm-ai') run(tab, function () { return aiExportTab(tab); });
});

chrome.commands.onCommand.addListener(function (command, tab) {
  function withTab(fn) {
    if (tab && tab.id) return fn(tab);
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) { if (tabs[0]) fn(tabs[0]); });
  }
  withTab(function (t) {
    if (command === 'convert-page') run(t, function () { return convertTab(t, false); });
    else if (command === 'export-ai-chat') {
      // Known AI sites go straight to the chat export. Anywhere else, try the
      // general chat reader and fall back to a plain page conversion.
      run(t, function () {
        if (isAiUrl(t.url)) return aiExportTab(t);
        return aiExportTab(t).catch(function () { return convertTab(t, false); });
      });
    }
  });
});

// The AI chat export asks for files on sites that block downloads from the
// page itself (Google's image server for Gemini pictures, Grok's asset
// server, an AI app's CDN). Only https and only from a tab; cookies only for
// the known file hosts below.
var PTM_FETCH_HOSTS = /^https:\/\/([a-z0-9-]+\.)*(googleusercontent\.com|ggpht\.com|grok\.com|x\.ai|oaiusercontent\.com)\//i;
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (!msg || msg.type !== 'ptm-fetch' || !sender || !sender.tab) return;
  var url = String(msg.url || '');
  if (!/^https:\/\//i.test(url)) { sendResponse({ ok: false }); return; }
  // Known file hosts get the user's cookies (their pictures need them); any
  // other https address is fetched without cookies, so nothing private leaks.
  fetch(url, { credentials: PTM_FETCH_HOSTS.test(url) ? 'include' : 'omit' })
    .then(function (r) { return r.ok ? r.arrayBuffer() : null; })
    .then(function (buf) {
      if (!buf) { sendResponse({ ok: false }); return; }
      var bytes = new Uint8Array(buf), bin = '';
      for (var i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
      sendResponse({ ok: true, b64: btoa(bin) });
    })
    .catch(function () { sendResponse({ ok: false }); });
  return true;
});
