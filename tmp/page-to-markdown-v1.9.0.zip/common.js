/**
 * common.js - helpers shared by the popup, runner, options and welcome
 * pages, and by the background service worker (via importScripts).
 * Nothing in here talks to the network.
 */
/* global chrome, PTM_CONFIG */

var PTM_DEFAULTS = {
  // AI chat export
  aiMode: 'full',            // 'full' | 'chat'
  aiSources: true,
  aiTrim: 0,                 // 0 = keep tool outputs in full
  aiRaw: false,              // also save an .mhtml copy of the page
  aiFiles: false,            // Claude: also save the files the chat made (.zip)
  aiUploads: false,          // ...and the files you uploaded
  aiCode: false,             // ...and code/config files (.js, .py, .css, .json...)
  // Output
  frontMatter: false,        // YAML block at the top (Obsidian, Notion, static sites)
  sourceHeader: true,        // "# Title / Source: url" header on page exports
  saveAs: false,             // ask where to save each file
  filenameTemplate: '{title}',
  // Pages
  usePresets: true,          // split forum threads into posts
  cleanMode: true,           // leave out ads, menus, sidebars, cookie banners
  copyInstead: false,        // copy to the clipboard instead of downloading
  // Your support page, if config.js has none (e.g. https://buymeacoffee.com/yourname)
  supportUrl: ''
};

// The support link: config.js wins, otherwise the one saved in Settings.
function ptmSupportUrl(settings) {
  return (typeof PTM_CONFIG !== 'undefined' && PTM_CONFIG.supportUrl) || (settings && settings.supportUrl) || '';
}

// The coffee choices: config.js tiers, else one "any amount" choice for a
// single support link. Empty when nothing is set up.
function ptmSupportTiers(settings) {
  var c = typeof PTM_CONFIG !== 'undefined' ? PTM_CONFIG : {};
  var tiers = (c.supportTiers || []).filter(function (t) { return t && /^https:\/\//.test(t.url || ''); });
  if (tiers.length) return tiers;
  var url = ptmSupportUrl(settings);
  return /^https:\/\//.test(url) ? [{ price: '', name: c.supportLabel || 'Buy me a coffee', note: '', icon: 'cup', url: url }] : [];
}

function ptmGetSettings() {
  return new Promise(function (resolve) {
    try {
      chrome.storage.sync.get(PTM_DEFAULTS, function (v) {
        resolve(Object.assign({}, PTM_DEFAULTS, v || {}));
      });
    } catch (e) { resolve(Object.assign({}, PTM_DEFAULTS)); }
  });
}

function ptmSetSettings(patch) {
  return new Promise(function (resolve) {
    try { chrome.storage.sync.set(patch, function () { resolve(); }); } catch (e) { resolve(); }
  });
}

function ptmLocalGet(keys) {
  return new Promise(function (resolve) {
    try { chrome.storage.local.get(keys, function (v) { resolve(v || {}); }); } catch (e) { resolve({}); }
  });
}

function ptmLocalSet(obj) {
  return new Promise(function (resolve) {
    try { chrome.storage.local.set(obj, function () { resolve(); }); } catch (e) { resolve(); }
  });
}

// Counts successful exports (used only to decide when to show the
// "Enjoying it?" card). Stored locally on this device, never sent anywhere.
function ptmCountExport() {
  return ptmLocalGet({ exportCount: 0 }).then(function (v) {
    return ptmLocalSet({ exportCount: (v.exportCount || 0) + 1 });
  });
}

function ptmDateStamp(d) {
  d = d || new Date();
  function p(n) { return (n < 10 ? '0' : '') + n; }
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function ptmCleanName(s) {
  return String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim();
}

// Template tokens: {title} {site} {date} {mode}
function ptmFilename(template, info) {
  var t = (template || '{title}').replace(/\{(\w+)\}/g, function (m, k) {
    if (k === 'title') return info.title || 'page';
    if (k === 'site') return info.site || '';
    if (k === 'date') return ptmDateStamp();
    if (k === 'mode') return info.mode || '';
    return m;
  });
  t = ptmCleanName(t).replace(/^[\s.\-]+|[\s.\-]+$/g, '').slice(0, 120);
  return (t || 'page') + '.md';
}

function ptmYaml(v) {
  return '"' + String(v == null ? '' : v).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, ' ') + '"';
}

function ptmFrontMatter(info) {
  var lines = ['---',
    'title: ' + ptmYaml(info.title),
    'source: ' + ptmYaml(info.url),
    info.site ? 'site: ' + ptmYaml(info.site) : '',
    'exported: ' + ptmYaml(new Date().toISOString()),
    info.type ? 'type: ' + ptmYaml(info.type) : '',
    'tags: [web-clip]',
    '---', ''];
  return lines.filter(function (l) { return l !== ''; }).join('\n') + '\n\n';
}

function ptmHost(url) {
  try { return new URL(url).hostname.replace(/^www\./, ''); } catch (e) { return ''; }
}

// Opens the coffee picker in its own tab (from pages other than the popup).
function ptmOpenSupport() {
  try { chrome.tabs.create({ url: chrome.runtime.getURL('support.html') }); } catch (e) { window.open('support.html', '_blank'); }
}

function ptmOpen(url) {
  if (!url) return;
  try { chrome.tabs.create({ url: url }); } catch (e) { window.open(url, '_blank', 'noopener'); }
}

/* ---------------------------------------------------------------------- *
 * AI chat sites. The popup offers "Export AI chat" by itself only on these
 * (matched by address, not by guessing from the page, which wrongly picked
 * up ordinary pages). Any other page can still be exported as a chat with the
 * "Export it as an AI chat" link. Built from the 2026 Similarweb "AI chatbots
 * and tools" ranking plus research and agent tools.
 * Each entry: [host pattern, name, optional path pattern].
 * ---------------------------------------------------------------------- */
var PTM_AI_SITES = [
  // Big ones with their own exporters
  [/^([\w-]+\.)?claude\.ai$/, 'Claude'], [/^(chatgpt\.com|chat\.openai\.com)$/, 'ChatGPT'],
  [/^gemini\.google\.com$/, 'Gemini'], [/^grok\.com$/, 'Grok'], [/^x\.com$/, 'Grok', /^\/i\/grok/],
  // General assistants
  [/^(chat\.)?deepseek\.com$/, 'DeepSeek'], [/^(www\.)?perplexity\.ai$/, 'Perplexity'],
  [/^copilot\.microsoft\.com$|^(m365\.)?copilot\.cloud\.microsoft$|^m365\.cloud\.microsoft$/, 'Copilot'],
  [/^(www\.)?bing\.com$/, 'Copilot', /^\/chat/], [/^(chat\.)?qwen\.ai$|^tongyi\.aliyun\.com$|^(www\.)?qianwen\.com$/, 'Qwen'],
  [/^(www\.)?meta\.ai$/, 'Meta AI'], [/^(www\.)?kimi\.(com|ai)$|^kimi\.moonshot\.cn$/, 'Kimi'],
  [/^duck\.ai$/, 'Duck.ai'], [/^duckduckgo\.com$/, 'Duck.ai', /^\/(chat|aichat)/],
  [/^chat\.mistral\.ai$/, 'Le Chat'], [/^(www\.)?poe\.com$/, 'Poe'], [/^(www\.)?you\.com$/, 'You.com'],
  [/^(www\.)?pi\.ai$/, 'Pi'], [/^huggingface\.co$/, 'HuggingChat', /^\/chat/], [/^(www\.)?doubao\.com$/, 'Doubao'],
  [/^yuanbao\.tencent\.com$/, 'Yuanbao'], [/^(chat\.)?z\.ai$|^(www\.)?chatglm\.cn$/, 'Z.ai'], [/^(www\.)?hailuoai\.com$|^chat\.minimax\.io$/, 'MiniMax'],
  [/^giga\.chat$/, 'GigaChat'], [/^alexa\.amazon\.com$/, 'Alexa+'], [/^(www\.)?chaton\.ai$/, 'ChatOn'],
  [/^(web\.)?chatbotapp\.ai$/, 'Chatbot App'], [/^(www\.)?monica\.im$/, 'Monica'], [/^(www\.)?getmerlin\.in$/, 'Merlin'],
  [/^(www\.)?hix\.ai$/, 'HIX'], [/^(www\.)?phind\.com$/, 'Phind'], [/^(www\.)?blackbox\.ai$/, 'Blackbox AI'],
  // Google tools
  [/^aistudio\.google\.com$/, 'Google AI Studio'], [/^notebooklm\.google\.com$/, 'NotebookLM'],
  // Multi-model chat apps
  [/^openrouter\.ai$/, 'OpenRouter', /^\/chat/], [/^(www\.)?lmarena\.ai$/, 'LMArena'], [/^(www\.)?t3\.chat$/, 'T3 Chat'],
  [/^(www\.)?typingmind\.com$/, 'TypingMind'], [/^(chatllm|apps)\.abacus\.ai$/, 'Abacus ChatLLM'],
  [/^(www\.)?librechat\.ai$/, 'LibreChat'], [/^(www\.)?msty\.(app|ai)$/, 'Msty'],
  // Agents and research
  [/^(www\.)?manus\.im$/, 'Manus'], [/^(www\.)?genspark\.ai$/, 'Genspark'], [/^(www\.)?flowith\.io$/, 'Flowith'],
  [/^(app\.)?liner\.com$|^(www\.)?getliner\.com$/, 'Liner'], [/^(www\.)?elicit\.com$/, 'Elicit'], [/^consensus\.app$/, 'Consensus'],
  [/^(www\.)?scite\.ai$/, 'Scite'], [/^(www\.)?julius\.ai$/, 'Julius'], [/^(www\.)?paperguide\.ai$/, 'Paperguide'],
  [/^(www\.)?chatpdf\.com$/, 'ChatPDF'], [/^(app\.)?devin\.ai$/, 'Devin'],
  // App builders (their chat with the builder)
  [/^(www\.)?lovable\.dev$/, 'Lovable', /^\/projects/], [/^bolt\.new$/, 'Bolt'], [/^v0\.(dev|app)$/, 'v0'],
  [/^(app\.)?base44\.(com|app)$/, 'Base44'],
  // Work and finance tools
  [/^(app\.)?tracelight\.ai$/, 'Tracelight'], [/^(app\.)?glean\.com$/, 'Glean'], [/^(app\.)?harvey\.ai$/, 'Harvey'],
  [/^(app\.)?hebbia\.(ai|com)$/, 'Hebbia'], [/^(app\.)?rogo\.ai$/, 'Rogo'], [/^(research\.)?alpha-sense\.com$/, 'AlphaSense'],
  [/^(www\.)?fiscal\.ai$/, 'Fiscal.ai'], [/^(app\.)?jasper\.ai$/, 'Jasper'], [/^(app\.)?brightwave\.io$/, 'Brightwave'],
  // Character and companion chat
  [/^(beta\.)?character\.ai$/, 'Character.AI'], [/^(www\.)?polybuzz\.ai$/, 'PolyBuzz'], [/^(www\.)?janitorai\.com$/, 'JanitorAI'],
  [/^(www\.)?spicychat\.ai$/, 'SpicyChat'], [/^(www\.)?crushon\.ai$/, 'CrushOn']
];

// { name, custom } for an AI chat address, or null. custom: true for the
// four sites that have their own exporters.
function ptmAiSiteFor(url) {
  var u;
  try { u = new URL(url); } catch (e) { return null; }
  if (!/^https?:$/.test(u.protocol)) return null;
  var host = u.hostname.toLowerCase();
  for (var i = 0; i < PTM_AI_SITES.length; i++) {
    var s = PTM_AI_SITES[i];
    if (s[0].test(host) && (!s[2] || s[2].test(u.pathname))) {
      return { name: s[1], custom: /^(Claude|ChatGPT|Gemini|Grok)$/.test(s[1]) };
    }
  }
  return null;
}

/* ---------------------------------------------------------------------- *
 * Saving files.
 * The file name is set on a download link (<a download="name">), not only
 * passed to chrome.downloads.download. Reason: when any other installed
 * extension watches downloads (downloads.onDeterminingFilename), Chrome
 * drops the filename given to chrome.downloads.download and saves blobs
 * under a random id ("0631ceef-....md") or data URLs as "download". A link's
 * own name survives that. chrome.downloads is used only for "Ask where to
 * save" (the dialog lets you name the file) and in the background worker,
 * which has no page; there the link is clicked inside the tab instead.
 * ---------------------------------------------------------------------- */
function ptmLinkDownload(url, filename) {
  var a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  (document.body || document.documentElement).appendChild(a);
  a.click();
  setTimeout(function () { a.remove(); }, 1000);
}

// AI sites whose exporter can also save the files a chat made (popup tick box).
var PTM_FILE_SITES = /^https:\/\/([a-z0-9-]+\.)?(claude\.ai|chatgpt\.com|chat\.openai\.com|gemini\.google\.com|grok\.com)\//i;

function ptmDownload(url, filename, saveAs) {
  return new Promise(function (resolve) {
    if (!saveAs && typeof document !== 'undefined' && document.createElement) {
      try { ptmLinkDownload(url, filename); resolve(1); return; } catch (e) { /* fall back below */ }
    }
    chrome.downloads.download({ url: url, filename: filename, saveAs: !!saveAs }, function (id) {
      void chrome.runtime.lastError;
      resolve(id || 0);
    });
  });
}

function ptmSaveText(filename, text, saveAs) {
  if (typeof URL !== 'undefined' && URL.createObjectURL && typeof Blob !== 'undefined') {
    try {
      var url = URL.createObjectURL(new Blob([text], { type: 'text/markdown;charset=utf-8' }));
      return ptmDownload(url, filename, saveAs).then(function (id) {
        setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
        return id;
      });
    } catch (e) { /* worker without blob URLs: use a data URL */ }
  }
  return ptmDownload('data:text/markdown;charset=utf-8,' + encodeURIComponent(text), filename, saveAs);
}
